import { useMemo } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import useLocalStorage from './useLocalStorage';
import { donneesDemo as mockData } from '@/data/mockData_final';
import { DonneesBusiness, Client, Vente, Tache, Depense, Alerte, Filtres, ChiffresCles, StatistiquesAvancees } from '@/types';

export function useBusinessData() {
  const [data, setData] = useLocalStorage<DonneesBusiness>('business-data', mockData);
  const [filtres, setFiltres] = useLocalStorage<Filtres>('business-filtres', {});

  // Fonctions CRUD pour les clients
  const ajouterClient = (client: Omit<Client, 'id'>) => {
    const nouveauClient: Client = {
      ...client,
      id: Date.now().toString(),
    };
    setData(prev => ({
      ...prev,
      clients: [...prev.clients, nouveauClient]
    }));
  };

  const modifierClient = (id: string, client: Partial<Client>) => {
    setData(prev => ({
      ...prev,
      clients: prev.clients.map(c => c.id === id ? { ...c, ...client } : c)
    }));
  };

  const supprimerClient = (id: string) => {
    setData(prev => ({
      ...prev,
      clients: prev.clients.filter(c => c.id !== id),
      ventes: prev.ventes.filter(v => v.clientId !== id)
    }));
  };

  // Fonctions CRUD pour les ventes
  const ajouterVente = (vente: Omit<Vente, 'id'>) => {
    const nouvelleVente: Vente = {
      ...vente,
      id: Date.now().toString(),
    };
    setData(prev => ({
      ...prev,
      ventes: [...prev.ventes, nouvelleVente]
    }));
  };

  const modifierVente = (id: string, vente: Partial<Vente>) => {
    setData(prev => ({
      ...prev,
      ventes: prev.ventes.map(v => v.id === id ? { ...v, ...vente } : v)
    }));
  };

  const supprimerVente = (id: string) => {
    setData(prev => ({
      ...prev,
      ventes: prev.ventes.filter(v => v.id !== id)
    }));
  };

  // Fonctions CRUD pour les tâches
  const ajouterTache = (tache: Omit<Tache, 'id'>) => {
    const nouvelleTache: Tache = {
      ...tache,
      id: Date.now().toString(),
    };
    setData(prev => ({
      ...prev,
      taches: [...prev.taches, nouvelleTache]
    }));
  };

  const modifierTache = (id: string, tache: Partial<Tache>) => {
    setData(prev => ({
      ...prev,
      taches: prev.taches.map(t => t.id === id ? { ...t, ...tache } : t)
    }));
  };

  const supprimerTache = (id: string) => {
    setData(prev => ({
      ...prev,
      taches: prev.taches.filter(t => t.id !== id)
    }));
  };

  // Fonctions CRUD pour les dépenses
  const ajouterDepense = (depense: Omit<Depense, 'id'>) => {
    const nouvelleDepense: Depense = {
      ...depense,
      id: Date.now().toString(),
    };
    setData(prev => ({
      ...prev,
      depenses: [...prev.depenses, nouvelleDepense]
    }));
  };

  const modifierDepense = (id: string, depense: Partial<Depense>) => {
    setData(prev => ({
      ...prev,
      depenses: prev.depenses.map(d => d.id === id ? { ...d, ...depense } : d)
    }));
  };

  const supprimerDepense = (id: string) => {
    setData(prev => ({
      ...prev,
      depenses: prev.depenses.filter(d => d.id !== id)
    }));
  };

  // Fonctions CRUD pour les alertes
  const ajouterAlerte = (alerte: Omit<Alerte, 'id'>) => {
    const nouvelleAlerte: Alerte = {
      ...alerte,
      id: Date.now().toString(),
    };
    setData(prev => ({
      ...prev,
      alertes: [...(prev.alertes || []), nouvelleAlerte]
    }));
  };

  const modifierAlerte = (id: string, alerte: Partial<Alerte>) => {
    setData(prev => ({
      ...prev,
      alertes: (prev.alertes || []).map(a => a.id === id ? { ...a, ...alerte } : a)
    }));
  };

  const supprimerAlerte = (id: string) => {
    setData(prev => ({
      ...prev,
      alertes: (prev.alertes || []).filter(a => a.id !== id)
    }));
  };

  const marquerAlerteCommeTraitee = (id: string) => {
    modifierAlerte(id, { estTraitee: true });
  };

  const snoozerAlerte = (id: string, dureeHeures: number = 24) => {
    const dateMiseEnSommeil = new Date();
    dateMiseEnSommeil.setHours(dateMiseEnSommeil.getHours() + dureeHeures);
    modifierAlerte(id, { 
      dateMiseEnSommeil: dateMiseEnSommeil.toISOString()
      // Ne pas marquer comme traitée, juste reporter
    });
  };

  // Fonction pour réinitialiser les filtres
  const reinitialiserFiltres = () => {
    setFiltres({});
  };

  // Calcul des données filtrées
  const donneesFiltrées = useMemo(() => {
    let clientsFiltres = data.clients;
    let ventesFiltrees = data.ventes;
    let tachesFiltrees = data.taches;

    // Filtre par client
    if (filtres.clientId) {
      clientsFiltres = clientsFiltres.filter(c => c.id === filtres.clientId);
      ventesFiltrees = ventesFiltrees.filter(v => v.clientId === filtres.clientId);
      tachesFiltrees = tachesFiltrees.filter(t => t.clientId === filtres.clientId);
    }

    // Filtre par statut client
    if (filtres.statutClient) {
      clientsFiltres = clientsFiltres.filter(c => c.statut === filtres.statutClient);
    }

    // Filtre par statut vente
    if (filtres.statutVente) {
      ventesFiltrees = ventesFiltrees.filter(v => v.statut === filtres.statutVente);
    }

    // Filtre par statut tâche
    if (filtres.statutTache) {
      tachesFiltrees = tachesFiltrees.filter(t => t.statut === filtres.statutTache);
    }

    // Filtre par mois
    if (filtres.mois) {
      const moisFiltre = filtres.mois;
      ventesFiltrees = ventesFiltrees.filter(v => 
        format(new Date(v.date), 'yyyy-MM') === moisFiltre
      );
      tachesFiltrees = tachesFiltrees.filter(t => 
        format(new Date(t.deadline), 'yyyy-MM') === moisFiltre
      );
    }

    return {
      clients: clientsFiltres,
      ventes: ventesFiltrees,
      taches: tachesFiltrees,
      depenses: data.depenses
    };
  }, [data, filtres]);

  // Calcul des chiffres clés mensuels
  const chiffresCles = useMemo(() => {
    const moisData: { [mois: string]: ChiffresCles } = {};

    // Traitement des ventes
    data.ventes.forEach(vente => {
      if (vente.statut === 'Confirmée') {
        const mois = format(new Date(vente.date), 'yyyy-MM');
        if (!moisData[mois]) {
          moisData[mois] = {
            mois: format(new Date(vente.date), 'MMMM yyyy', { locale: fr }),
            ca: 0,
            nombreVentes: 0,
            depenses: 0,
            benefice: 0
          };
        }
        moisData[mois].ca += vente.montant;
        moisData[mois].nombreVentes += 1;
      }
    });

    // Traitement des dépenses
    data.depenses.forEach(depense => {
      const mois = format(new Date(depense.date), 'yyyy-MM');
      if (!moisData[mois]) {
        moisData[mois] = {
          mois: format(new Date(depense.date), 'MMMM yyyy', { locale: fr }),
          ca: 0,
          nombreVentes: 0,
          depenses: 0,
          benefice: 0
        };
      }
      moisData[mois].depenses += depense.montant;
    });

    // Calcul des bénéfices
    Object.keys(moisData).forEach(mois => {
      moisData[mois].benefice = moisData[mois].ca - moisData[mois].depenses;
    });

    return Object.values(moisData).sort((a, b) => 
      new Date(b.mois).getTime() - new Date(a.mois).getTime()
    );
  }, [data]);

  // Fonction pour obtenir le nom du client par ID
  const obtenirNomClient = (clientId: string): string => {
    const client = data.clients.find(c => c.id === clientId);
    return client ? client.nom : 'Client inconnu';
  };

  // Détection automatique des alertes
  const detecterAlertesAutomatiques = useMemo(() => {
    const alertesDetectees: Omit<Alerte, 'id'>[] = [];
    const maintenantDate = new Date();
    const aujourd_hui = format(maintenantDate, 'yyyy-MM-dd');

    // Détection des tâches en retard
    data.taches.forEach(tache => {
      if (tache.statut !== 'Terminé' && new Date(tache.deadline) < maintenantDate) {
        const joursRetard = Math.floor((maintenantDate.getTime() - new Date(tache.deadline).getTime()) / (1000 * 60 * 60 * 24));
        const clientNom = obtenirNomClient(tache.clientId);
        
        // Vérifier si cette alerte existe déjà (traitée ou non)
        const alerteExiste = (data.alertes || []).some(a => 
          a.type === 'tache-retard' && 
          a.elementId === tache.id
        );

        if (!alerteExiste) {
          alertesDetectees.push({
            type: 'tache-retard',
            titre: 'Tâche en retard',
            description: `La tâche "${tache.nom}" pour ${clientNom} est en retard depuis ${joursRetard} jour${joursRetard > 1 ? 's' : ''}`,
            niveau: joursRetard > 3 ? 'critique' : 'important',
            dateDetection: aujourd_hui,
            estTraitee: false,
            elementId: tache.id
          });
        }
      }
    });

    // Détection des clients inactifs (plus de 15 jours sans contact)
    data.clients.forEach(client => {
      const dernierContact = new Date(client.dateDernierEchange);
      const joursInactif = Math.floor((maintenantDate.getTime() - dernierContact.getTime()) / (1000 * 60 * 60 * 24));
      
      if (joursInactif > 15) {
        // Vérifier si cette alerte existe déjà (traitée ou non)
        const alerteExiste = (data.alertes || []).some(a => 
          a.type === 'client-inactif' && 
          a.elementId === client.id
        );

        if (!alerteExiste) {
          alertesDetectees.push({
            type: 'client-inactif',
            titre: 'Client inactif',
            description: `${client.nom} n'a pas été contacté depuis ${joursInactif} jours (dernier contact: ${format(dernierContact, 'dd/MM/yyyy', { locale: fr })})`,
            niveau: joursInactif > 30 ? 'important' : 'info',
            dateDetection: aujourd_hui,
            estTraitee: false,
            elementId: client.id
          });
        }
      }
    });

    return alertesDetectees;
  }, [data.taches, data.clients, data.alertes]);

  // Calcul des statistiques avancées
  const statistiquesAvancees = useMemo((): StatistiquesAvancees => {
    // Évolution sur 6 mois
    const evolutionSurSixMois = chiffresCles.slice(0, 6).reverse().map(mois => ({
      mois: mois.mois,
      ca: mois.ca,
      depenses: mois.depenses,
      benefice: mois.benefice,
      nombreVentes: mois.nombreVentes
    }));

    // Répartition CA par client pour le mois actuel
    const moisActuel = format(new Date(), 'yyyy-MM');
    const ventesParClient: { [clientId: string]: { clientNom: string; montant: number } } = {};
    
    data.ventes
      .filter(v => v.statut === 'Confirmée' && format(new Date(v.date), 'yyyy-MM') === moisActuel)
      .forEach(vente => {
        if (!ventesParClient[vente.clientId]) {
          ventesParClient[vente.clientId] = {
            clientNom: obtenirNomClient(vente.clientId),
            montant: 0
          };
        }
        ventesParClient[vente.clientId].montant += vente.montant;
      });

    const ventesParClientArray = Object.entries(ventesParClient).map(([clientId, data]) => ({
      clientId,
      clientNom: data.clientNom,
      montant: data.montant
    }));

    return {
      moisSelectionne: moisActuel,
      derniersStatistiques: chiffresCles.slice(0, 3).map(mois => ({
        ...mois,
        ventesParClient: ventesParClientArray,
        tendanceVentes: chiffresCles.slice(0, 6).reverse().map(m => ({
          mois: m.mois,
          nombreVentes: m.nombreVentes,
          ca: m.ca
        }))
      })),
      evolutionSurSixMois
    };
  }, [chiffresCles, data.ventes]);

  // Alertes actives (non traitées et non en sommeil)
  const alertesActives = useMemo(() => {
    const maintenantDate = new Date();
    return (data.alertes || []).filter(alerte => 
      !alerte.estTraitee && 
      (!alerte.dateMiseEnSommeil || new Date(alerte.dateMiseEnSommeil) < maintenantDate)
    );
  }, [data.alertes]);

  return {
    data: donneesFiltrées,
    dataComplete: data,
    filtres,
    setFiltres,
    reinitialiserFiltres,
    chiffresCles,
    obtenirNomClient,
    // CRUD clients
    ajouterClient,
    modifierClient,
    supprimerClient,
    // CRUD ventes
    ajouterVente,
    modifierVente,
    supprimerVente,
    // CRUD tâches
    ajouterTache,
    modifierTache,
    supprimerTache,
    // CRUD dépenses
    ajouterDepense,
    modifierDepense,
    supprimerDepense,
    // CRUD alertes
    ajouterAlerte,
    modifierAlerte,
    supprimerAlerte,
    marquerAlerteCommeTraitee,
    snoozerAlerte,
    // Nouvelles fonctionnalités
    statistiquesAvancees,
    alertesActives,
    detecterAlertesAutomatiques
  };
}
