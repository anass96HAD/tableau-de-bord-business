// Types pour le tableau de bord business

export interface Client {
  id: string;
  nom: string;
  email: string;
  telephone: string;
  statut: 'Prospect' | 'Client' | 'Inactif';
  dateDernierEchange: string;
  dateCreation: string;
}

export interface Vente {
  id: string;
  produitService: string;
  montant: number;
  date: string;
  clientId: string;
  statut: 'En cours' | 'Confirmée' | 'Annulée';
  description?: string;
}

export interface Tache {
  id: string;
  nom: string; // Nouveau: nom descriptif de la tâche
  description?: string; // Optionnel: description détaillée
  clientId: string; // Nouveau: client associé à la tâche
  priorite: 'Haute' | 'Moyenne' | 'Basse'; // Changé: Basse au lieu de Faible
  deadline: string;
  statut: 'À faire' | 'En cours' | 'Terminé'; // Changé: Terminé au lieu de Terminée
  dateCreation: string;
}

export interface Depense {
  id: string;
  description: string;
  montant: number;
  date: string;
  categorie: 'Matériel' | 'Logiciel' | 'Transport' | 'Communication' | 'Autre';
}

export interface ChiffresCles {
  mois: string;
  ca: number;
  nombreVentes: number;
  depenses: number;
  benefice: number;
}

export interface Filtres {
  mois?: string;
  clientId?: string;
  statutClient?: Client['statut'];
  statutVente?: Vente['statut'];
  statutTache?: Tache['statut'];
}

// Nouveaux types pour les alertes
export interface Alerte {
  id: string;
  type: 'tache-retard' | 'client-inactif';
  titre: string;
  description: string;
  niveau: 'critique' | 'important' | 'info';
  dateDetection: string;
  estTraitee: boolean;
  dateMiseEnSommeil?: string; // Pour snoozer l'alerte
  elementId: string; // ID de la tâche ou du client concerné
}

// Nouveaux types pour les statistiques avancées
export interface StatistiquesMensuelles extends ChiffresCles {
  ventesParClient: { clientId: string; clientNom: string; montant: number }[];
  tendanceVentes: { mois: string; nombreVentes: number; ca: number }[];
}

export interface StatistiquesAvancees {
  moisSelectionne: string;
  derniersStatistiques: StatistiquesMensuelles[];
  evolutionSurSixMois: {
    mois: string;
    ca: number;
    depenses: number;
    benefice: number;
    nombreVentes: number;
  }[];
}

export interface DonneesBusiness {
  clients: Client[];
  ventes: Vente[];
  taches: Tache[];
  depenses: Depense[];
  alertes: Alerte[]; // Nouveau: système d'alertes
}
