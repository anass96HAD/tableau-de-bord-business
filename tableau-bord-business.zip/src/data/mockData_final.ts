import { Client, Vente, Tache, Depense, Alerte, DonneesBusiness } from '@/types';
import { mockDepensesCorrect } from './mockDepenses_temp';

// Clients de démonstration
export const mockClients: Client[] = [
  {
    id: '1',
    nom: 'TechnoSoft SARL',
    email: 'contact@technosoft.fr',
    telephone: '01 42 85 96 32',
    statut: 'Client',
    dateDernierEchange: '2025-05-28',
    dateCreation: '2023-01-15'
  },
  {
    id: '2',
    nom: 'Creative Agency',
    email: 'hello@creative-agency.com',
    telephone: '02 35 74 81 29',
    statut: 'Client',
    dateDernierEchange: '2025-05-20',
    dateCreation: '2023-03-10'
  },
  {
    id: '3',
    nom: 'StartupLab',
    email: 'team@startuplab.fr',
    telephone: '04 67 89 23 45',
    statut: 'Prospect',
    dateDernierEchange: '2025-05-15',
    dateCreation: '2024-11-20'
  },
  {
    id: '4',
    nom: 'E-Commerce Plus',
    email: 'contact@ecommerce-plus.fr',
    telephone: '03 28 91 47 56',
    statut: 'Client',
    dateDernierEchange: '2025-05-25',
    dateCreation: '2022-08-05'
  },
  {
    id: '5',
    nom: 'Digital Solutions',
    email: 'info@digital-solutions.com',
    telephone: '05 61 34 78 92',
    statut: 'Client',
    dateDernierEchange: '2025-05-18',
    dateCreation: '2023-06-12'
  }
];

// Ventes de démonstration
export const mockVentes: Vente[] = [
  {
    id: '1',
    produitService: 'Site vitrine corporate',
    montant: 4500,
    date: '2024-12-05',
    clientId: '3',
    statut: 'Confirmée',
    description: 'Refonte complète du site web'
  },
  {
    id: '2',
    produitService: 'Application mobile',
    montant: 12800,
    date: '2025-01-15',
    clientId: '4',
    statut: 'Confirmée',
    description: 'Développement app mobile'
  },
  {
    id: '3',
    produitService: 'Maintenance site web',
    montant: 800,
    date: '2025-02-20',
    clientId: '1',
    statut: 'Confirmée',
    description: 'Maintenance mensuelle'
  }
];

// Tâches de démonstration
export const mockTaches: Tache[] = [
  {
    id: '1',
    nom: 'Finaliser maquettes app mobile',
    description: 'Finaliser le design de l\'application mobile',
    clientId: '4',
    priorite: 'Haute',
    deadline: '2025-06-03',
    statut: 'En cours',
    dateCreation: '2025-05-20'
  },
  {
    id: '2',
    nom: 'Tests utilisateurs',
    description: 'Organiser les tests utilisateurs',
    clientId: '2',
    priorite: 'Moyenne',
    deadline: '2025-06-10',
    statut: 'À faire',
    dateCreation: '2025-05-15'
  },
  {
    id: '3',
    nom: 'Documentation projet',
    description: 'Rédiger la documentation',
    clientId: '5',
    priorite: 'Basse',
    deadline: '2025-06-20',
    statut: 'Terminé',
    dateCreation: '2025-05-10'
  }
];

// Dépenses de démonstration
export const mockDepenses = mockDepensesCorrect;

// Alertes de démonstration
export const mockAlertes: Alerte[] = [
  {
    id: '1',
    type: 'tache-retard',
    titre: 'Tâche en retard',
    description: 'La tâche "Finaliser maquettes app mobile" est en retard depuis 2 jours',
    niveau: 'critique',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '1'
  }
];

// Données principales
export const donneesDemo: DonneesBusiness = {
  clients: mockClients,
  ventes: mockVentes,
  taches: mockTaches,
  depenses: mockDepensesCorrect,
  alertes: mockAlertes
};

// Export par défaut
export default donneesDemo;
