import { Depense } from '@/types';

export const mockDepensesCorrect: Depense[] = [
  // Mars 2025
  {
    id: '1',
    description: 'Ordinateurs portables équipe',
    montant: 2400,
    date: '2025-03-01',
    categorie: 'Matériel'
  },
  {
    id: '2',
    description: 'Licences Adobe Creative Suite',
    montant: 680,
    date: '2025-03-05',
    categorie: 'Logiciel'
  },
  {
    id: '3',
    description: 'Déplacement client Paris',
    montant: 320,
    date: '2025-03-10',
    categorie: 'Transport'
  },
  {
    id: '4',
    description: 'Abonnement téléphone professionnel',
    montant: 180,
    date: '2025-03-15',
    categorie: 'Communication'
  },
  
  // Avril 2025
  {
    id: '5',
    description: 'Écrans 4K pour développeurs',
    montant: 800,
    date: '2025-04-02',
    categorie: 'Matériel'
  },
  {
    id: '6',
    description: 'Serveur de sauvegarde',
    montant: 450,
    date: '2025-04-08',
    categorie: 'Matériel'
  },
  {
    id: '7',
    description: 'Licence Microsoft Office 365',
    montant: 300,
    date: '2025-04-12',
    categorie: 'Logiciel'
  },
  {
    id: '8',
    description: 'Formation sécurité informatique',
    montant: 850,
    date: '2025-04-18',
    categorie: 'Autre'
  },
  {
    id: '9',
    description: 'Mission Lyon client',
    montant: 280,
    date: '2025-04-22',
    categorie: 'Transport'
  },
  
  // Mai 2025
  {
    id: '10',
    description: 'Logiciel de gestion projet',
    montant: 420,
    date: '2025-05-03',
    categorie: 'Logiciel'
  },
  {
    id: '11',
    description: 'Internet fibre entreprise',
    montant: 120,
    date: '2025-05-05',
    categorie: 'Communication'
  },
  {
    id: '12',
    description: 'Assurance matériel informatique',
    montant: 380,
    date: '2025-05-12',
    categorie: 'Autre'
  }
];
