import { Client, Vente, Tache, Depense, Alerte, DonneesBusiness } from '@/types';
import { mockDepensesCorrect } from './mockDepenses_temp';

// Clients de démonstration
export const mockClients: Client[] = [
  {
    id: '1',
    nom: 'TechnoSoft SARL',
    email: 'contact@technosoft.fr',
    telephone: '01 42 85 96 32',
    statut: 'Client',
    dateDernierEchange: '2025-05-28'
  },
  {
    id: '2',
    nom: 'Creative Agency',
    email: 'hello@creative-agency.com',
    telephone: '02 35 74 81 29',
    statut: 'Client',
    dateDernierEchange: '2025-05-20'
  },
  {
    id: '3',
    nom: 'StartupLab',
    email: 'team@startuplab.fr',
    telephone: '04 67 89 23 45',
    statut: 'Prospect',
    dateDernierEchange: '2025-05-15'
  },
  {
    id: '4',
    nom: 'E-Commerce Plus',
    email: 'contact@ecommerce-plus.fr',
    telephone: '03 28 91 47 56',
    statut: 'Client',
    dateDernierEchange: '2025-05-25'
  },
  {
    id: '5',
    nom: 'Digital Solutions',
    email: 'info@digital-solutions.com',
    telephone: '05 61 34 78 92',
    statut: 'Client',
    dateDernierEchange: '2025-05-18'
  },
  {
    id: '6',
    nom: 'WebMaster Pro',
    email: 'contact@webmaster-pro.fr',
    telephone: '01 56 43 29 87',
    statut: 'Prospect',
    dateDernierEchange: '2025-05-10',
    notes: 'Demande de devis en cours'
  },
  {
    id: '7',
    nom: 'Marketing Boost',
    email: 'hello@marketing-boost.fr',
    telephone: '02 41 78 56 34',
    statut: 'Client',
    dateDernierEchange: '2025-05-22',
    notes: 'Agence marketing digital'
  },
  {
    id: '8',
    nom: 'InnovaTech Solutions',
    email: 'contact@innovatech.fr',
    telephone: '04 76 92 18 53',
    statut: 'Client',
    dateDernierEchange: '2025-05-30',
    notes: 'Développement d\'applications mobiles'
  },
  {
    id: '9',
    nom: 'Business Corp',
    email: 'info@business-corp.com',
    telephone: '01 45 67 89 23',
    statut: 'Client',
    dateDernierEchange: '2025-05-26',
    notes: 'Entreprise traditionnelle en digitalisation'
  },
  {
    id: '10',
    nom: 'Startup Innovation',
    email: 'team@startup-innovation.fr',
    telephone: '06 78 45 23 91',
    statut: 'Inactif',
    dateDernierEchange: '2025-03-01',
    notes: 'Pas de nouvelles depuis 3 mois'
  }
];

// Ventes de démonstration (6 mois de données)
export const mockVentes: Vente[] = [
  // Décembre 2024
  {
    id: '1',
    produitService: 'Site vitrine corporate',
    montant: 4500,
    date: '2024-12-05',
    clientId: '9',
    statut: 'Confirmée',
    description: 'Refonte complète du site web corporate'
  },
  {
    id: '2',
    produitService: 'Application mobile e-commerce',
    montant: 12800,
    date: '2024-12-15',
    clientId: '4',
    statut: 'Confirmée',
    description: 'Développement application mobile iOS/Android'
  },
  {
    id: '3',
    produitService: 'Maintenance site web',
    montant: 800,
    date: '2024-12-20',
    clientId: '1',
    statut: 'Confirmée',
    description: 'Contrat de maintenance mensuel'
  },

  // Janvier 2025
  {
    id: '4',
    produitService: 'Refonte UX/UI',
    montant: 6200,
    date: '2025-01-08',
    clientId: '2',
    statut: 'Confirmée',
    description: 'Refonte de l\'interface utilisateur'
  },
  {
    id: '5',
    produitService: 'SEO & référencement',
    montant: 1500,
    date: '2025-01-15',
    clientId: '7',
    statut: 'Confirmée',
    description: 'Optimisation SEO et stratégie de contenu'
  },
  {
    id: '6',
    produitService: 'Formation équipe',
    montant: 2400,
    date: '2025-01-22',
    clientId: '5',
    statut: 'Confirmée',
    description: 'Formation développement web moderne'
  },

  // Février 2025
  {
    id: '7',
    produitService: 'Site e-commerce',
    montant: 8900,
    date: '2025-02-03',
    clientId: '6',
    statut: 'Confirmée',
    description: 'Boutique en ligne avec système de paiement'
  },
  {
    id: '8',
    produitService: 'Application web métier',
    montant: 15600,
    date: '2025-02-18',
    clientId: '8',
    statut: 'Confirmée',
    description: 'Application de gestion interne'
  },
  {
    id: '9',
    produitService: 'Audit technique',
    montant: 1200,
    date: '2025-02-25',
    clientId: '3',
    statut: 'Confirmée',
    description: 'Audit de performance et sécurité'
  },

  // Mars 2025
  {
    id: '10',
    produitService: 'API développement',
    montant: 5800,
    date: '2025-03-05',
    clientId: '5',
    statut: 'Confirmée',
    description: 'Développement API REST personnalisée'
  },
  {
    id: '11',
    produitService: 'Consultation stratégique',
    montant: 2200,
    date: '2025-03-12',
    clientId: '7',
    statut: 'Confirmée',
    description: 'Conseil en transformation digitale'
  },
  {
    id: '12',
    produitService: 'Migration cloud',
    montant: 7400,
    date: '2025-03-20',
    clientId: '4',
    statut: 'Confirmée',
    description: 'Migration infrastructure vers le cloud'
  },

  // Avril 2025
  {
    id: '13',
    produitService: 'Dashboard analytics',
    montant: 4600,
    date: '2025-04-02',
    clientId: '2',
    statut: 'Confirmée',
    description: 'Tableau de bord avec données en temps réel'
  },
  {
    id: '14',
    produitService: 'Maintenance avancée',
    montant: 1800,
    date: '2025-04-15',
    clientId: '1',
    statut: 'Confirmée',
    description: 'Maintenance proactive et monitoring'
  },
  {
    id: '15',
    produitService: 'Module e-learning',
    montant: 9200,
    date: '2025-04-28',
    clientId: '8',
    statut: 'En cours',
    description: 'Plateforme de formation en ligne'
  },

  // Mai 2025
  {
    id: '16',
    produitService: 'App mobile startup',
    montant: 11400,
    date: '2025-05-05',
    clientId: '3',
    statut: 'En cours',
    description: 'Application mobile pour startup'
  },
  {
    id: '17',
    produitService: 'Intégration CRM',
    montant: 3800,
    date: '2025-05-18',
    clientId: '9',
    statut: 'En cours',
    description: 'Intégration système CRM existant'
  },
  {
    id: '18',
    produitService: 'Optimisation performance',
    montant: 2600,
    date: '2025-05-25',
    clientId: '7',
    statut: 'En cours',
    description: 'Optimisation vitesse et performance web'
  }
];

// Tâches de démonstration
export const mockTaches: Tache[] = [
  {
    id: '1',
    nom: 'Finaliser maquettes app mobile',
    description: 'Finaliser le design de l\'application mobile pour InnovaTech Solutions',
    clientId: '8',
    priorite: 'Haute',
    deadline: '2025-06-03', // Tâche en retard
    statut: 'En cours',
    dateCreation: '2025-05-20'
  },
  {
    id: '2',
    nom: 'Correction bugs app mobile',
    description: 'Corriger les bugs signalés sur l\'application mobile en développement',
    clientId: '8',
    priorite: 'Haute',
    deadline: '2025-06-02', // Tâche en retard
    statut: 'À faire',
    dateCreation: '2025-05-25'
  },
  {
    id: '3',
    nom: 'Tests utilisateurs dashboard',
    description: 'Organiser et analyser les tests utilisateurs pour le nouveau dashboard',
    clientId: '2',
    priorite: 'Moyenne',
    deadline: '2025-06-10',
    statut: 'À faire',
    dateCreation: '2025-05-15'
  },
  {
    id: '4',
    nom: 'Documentation API',
    description: 'Rédiger la documentation complète de l\'API REST développée',
    clientId: '5',
    priorite: 'Moyenne',
    deadline: '2025-06-15',
    statut: 'En cours',
    dateCreation: '2025-05-10'
  },
  {
    id: '5',
    nom: 'Formation client CRM',
    description: 'Préparer et animer la formation sur le nouveau système CRM',
    clientId: '9',
    priorite: 'Faible',
    deadline: '2025-06-20',
    statut: 'À faire',
    dateCreation: '2025-05-30'
  },
  {
    id: '6',
    nom: 'Audit sécurité site web',
    description: 'Effectuer un audit de sécurité complet du site e-commerce',
    clientId: '4',
    priorite: 'Haute',
    deadline: '2025-06-08',
    statut: 'À faire',
    dateCreation: '2025-05-28'
  },
  {
    id: '7',
    nom: 'Optimisation SEO',
    description: 'Implémenter les recommandations d\'optimisation SEO',
    clientId: '7',
    priorite: 'Moyenne',
    deadline: '2025-06-25',
    statut: 'En cours',
    dateCreation: '2025-05-22'
  },
  {
    id: '8',
    nom: 'Mise à jour framework',
    description: 'Mettre à jour le framework vers la dernière version stable',
    clientId: '1',
    priorite: 'Faible',
    deadline: '2025-06-30',
    statut: 'À faire',
    dateCreation: '2025-05-18'
  },
  {
    id: '9',
    nom: 'Backup automatique',
    description: 'Configurer le système de sauvegarde automatique',
    clientId: '5',
    priorite: 'Haute',
    deadline: '2025-06-12',
    statut: 'Terminée',
    dateCreation: '2025-05-12'
  },
  {
    id: '10',
    nom: 'Prototype interface',
    description: 'Créer le prototype interactif de la nouvelle interface',
    clientId: '3',
    priorite: 'Moyenne',
    deadline: '2025-06-18',
    statut: 'En cours',
    dateCreation: '2025-05-25'
  }
];

// Dépenses de démonstration (utilise les données du fichier temporaire)
export const mockDepenses = mockDepensesCorrect;

// Alertes de démonstration
export const mockAlertes: Alerte[] = [
  {
    id: '1',
    type: 'tache-retard',
    titre: 'Tâche en retard',
    description: 'La tâche "Finaliser maquettes app mobile" pour InnovaTech Solutions est en retard depuis 2 jours',
    niveau: 'critique',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '1'
  },
  {
    id: '2',
    type: 'tache-retard',
    titre: 'Tâche critique en retard',
    description: 'La tâche "Correction bugs app mobile" pour InnovaTech Solutions est en retard depuis 3 jours',
    niveau: 'critique',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '2'
  },
  {
    id: '3',
    type: 'client-inactif',
    titre: 'Client inactif',
    description: 'Le client "Startup Innovation" n\'a eu aucun échange depuis plus de 60 jours',
    niveau: 'important',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '10'
  }
];

// Données principales
export const donneesDemo: DonneesBusiness = {
  clients: mockClients,
  ventes: mockVentes,
  taches: mockTaches,
  depenses: mockDepensesCorrect,
  alertes: mockAlertes
};

// Export par défaut (compatibilité)
export default donneesDemo;
