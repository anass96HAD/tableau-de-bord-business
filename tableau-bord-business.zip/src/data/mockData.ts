import { Client, Vente, Tache, Depense, Alerte, DonneesBusiness } from '@/types';
import { mockDepensesCorrect } from './mockDepenses_temp';

// Données de démonstration réalistes étendues sur 6 mois
export const mockClients: Client[] = [
  {
    id: '1',
    nom: 'TechnoSoft SARL',
    email: 'contact@technosoft.fr',
    telephone: '01 42 85 96 32',
    statut: 'Client',
    dateDernierEchange: '2025-05-28',
    dateCreation: '2025-01-15'
  },
  {
    id: '2',
    nom: 'Digital Innovations',
    email: 'info@digital-innov.com',
    telephone: '04 76 45 23 18',
    statut: 'Client',
    dateDernierEchange: '2025-06-02',
    dateCreation: '2025-02-03'
  },
  {
    id: '3',
    nom: 'StartUp Creative',
    email: 'hello@startupcreative.fr',
    telephone: '05 56 78 41 29',
    statut: 'Prospect',
    dateDernierEchange: '2025-06-01',
    dateCreation: '2025-05-20'
  },
  {
    id: '4',
    nom: 'Consulting Plus',
    email: 'contact@consultingplus.fr',
    telephone: '02 98 32 54 76',
    statut: 'Client',
    dateDernierEchange: '2025-05-15',
    dateCreation: '2025-01-08'
  },
  {
    id: '5',
    nom: 'E-Commerce Solutions',
    email: 'support@ecommerce-sol.com',
    telephone: '03 88 45 67 89',
    statut: 'Prospect',
    dateDernierEchange: '2025-05-30',
    dateCreation: '2025-05-25'
  },
  {
    id: '6',
    nom: 'Marketing Pro',
    email: 'team@marketingpro.fr',
    telephone: '01 47 82 63 45',
    statut: 'Inactif',
    dateDernierEchange: '2025-03-12',
    dateCreation: '2024-11-20'
  },
  {
    id: '7',
    nom: 'Retail Connect',
    email: 'info@retailconnect.fr',
    telephone: '04 91 58 73 26',
    statut: 'Client',
    dateDernierEchange: '2025-06-03',
    dateCreation: '2025-03-10'
  },
  {
    id: '8',
    nom: 'InnovaTech Solutions',
    email: 'info@innovatech-solutions.fr',
    telephone: '01 45 78 92 36',
    statut: 'Prospect',
    dateDernierEchange: '2025-05-18', // Client inactif depuis plus de 15 jours
    dateCreation: '2025-04-10'
  },
  {
    id: '9',
    nom: 'WebDev Agency',
    email: 'contact@webdev-agency.com',
    telephone: '03 20 45 67 89',
    statut: 'Client',
    dateDernierEchange: '2025-04-20', // Client inactif depuis plus de 15 jours
    dateCreation: '2024-12-05'
  }
];

// Historique étendu de ventes sur 6 mois (décembre 2024 - mai 2025)
export const mockVentes: Vente[] = [
  // Décembre 2024
  {
    id: '1',
    produitService: 'Site vitrine corporate',
    montant: 4500,
    date: '2024-12-05',
    clientId: '9',
    statut: 'Confirmée',
    description: 'Site institutionnel responsive'
  },
  {
    id: '2',
    produitService: 'Maintenance annuelle',
    montant: 2400,
    date: '2024-12-15',
    clientId: '1',
    statut: 'Confirmée',
    description: 'Contrat maintenance 12 mois'
  },
  {
    id: '3',
    produitService: 'Audit sécurité',
    montant: 1800,
    date: '2024-12-20',
    clientId: '4',
    statut: 'Confirmée',
    description: 'Audit de sécurité complet'
  },
  
  // Janvier 2025
  {
    id: '4',
    produitService: 'Application mobile',
    montant: 12000,
    date: '2025-01-08',
    clientId: '2',
    statut: 'Confirmée',
    description: 'App iOS/Android native'
  },
  {
    id: '5',
    produitService: 'Formation React',
    montant: 3200,
    date: '2025-01-15',
    clientId: '7',
    statut: 'Confirmée',
    description: 'Formation équipe 4 jours'
  },
  {
    id: '6',
    produitService: 'Consultation stratégique',
    montant: 2500,
    date: '2025-01-25',
    clientId: '1',
    statut: 'Confirmée',
    description: 'Stratégie digitale 2025'
  },
  
  // Février 2025
  {
    id: '7',
    produitService: 'E-commerce sur mesure',
    montant: 8500,
    date: '2025-02-03',
    clientId: '5',
    statut: 'Confirmée',
    description: 'Boutique en ligne complète'
  },
  {
    id: '8',
    produitService: 'Optimisation SEO',
    montant: 1900,
    date: '2025-02-12',
    clientId: '3',
    statut: 'Confirmée',
    description: 'Audit et optimisation SEO'
  },
  {
    id: '9',
    produitService: 'API REST custom',
    montant: 5500,
    date: '2025-02-20',
    clientId: '9',
    statut: 'Confirmée',
    description: 'API métier personnalisée'
  },
  
  // Mars 2025
  {
    id: '10',
    produitService: 'Développement site web',
    montant: 8500,
    date: '2025-03-15',
    clientId: '1',
    statut: 'Confirmée',
    description: 'Site vitrine avec CMS'
  },
  {
    id: '11',
    produitService: 'Audit SEO',
    montant: 2200,
    date: '2025-03-22',
    clientId: '2',
    statut: 'Confirmée',
    description: 'Audit complet + recommandations'
  },
  {
    id: '12',
    produitService: 'Campagne publicitaire',
    montant: 2800,
    date: '2025-03-28',
    clientId: '6',
    statut: 'Annulée',
    description: 'Google Ads + Facebook'
  },
  
  // Avril 2025
  {
    id: '13',
    produitService: 'Migration cloud',
    montant: 7800,
    date: '2025-04-02',
    clientId: '4',
    statut: 'Confirmée',
    description: 'Migration vers AWS'
  },
  {
    id: '14',
    produitService: 'Formation équipe',
    montant: 3500,
    date: '2025-04-12',
    clientId: '1',
    statut: 'Confirmée',
    description: 'Formation équipe 5 jours'
  },
  {
    id: '15',
    produitService: 'Maintenance système',
    montant: 4800,
    date: '2025-04-18',
    clientId: '7',
    statut: 'Confirmée',
    description: 'Contrat maintenance 12 mois'
  },
  {
    id: '16',
    produitService: 'Consultation UX/UI',
    montant: 2800,
    date: '2025-04-25',
    clientId: '2',
    statut: 'Confirmée',
    description: 'Refonte interface utilisateur'
  },
  
  // Mai 2025
  {
    id: '17',
    produitService: 'Plateforme e-learning',
    montant: 12000,
    date: '2025-05-08',
    clientId: '5',
    statut: 'En cours',
    description: 'Plateforme de formation en ligne'
  },
  {
    id: '18',
    produitService: 'Analyse de données',
    montant: 4100,
    date: '2025-05-15',
    clientId: '4',
    statut: 'Confirmée',
    description: 'Dashboard analytics'
  },
  {
    id: '19',
    produitService: 'Application mobile',
    montant: 5500,
    date: '2025-05-22',
    clientId: '8',
    statut: 'En cours',
    description: 'App mobile métier'
  },
  {
    id: '20',
    produitService: 'Refonte site web',
    montant: 6200,
    date: '2025-05-28',
    clientId: '7',
    statut: 'Confirmée',
    description: 'Modernisation site vitrine'
  },
  
  // Juin 2025 (en cours)
  {
    id: '21',
    produitService: 'Hébergement premium',
    montant: 1200,
    date: '2025-06-04',
    clientId: '3',
    statut: 'En cours',
    description: 'Serveur dédié 12 mois'
  }
];

export const mockTaches: Tache[] = [
  {
    id: '1',
    nom: 'Finaliser maquettes app mobile',
    description: 'Finaliser le design de l\'application mobile pour InnovaTech Solutions',
    clientId: '8',
    priorite: 'Haute',
    deadline: '2025-06-03', // Tâche en retard
    statut: 'En cours',
    dateCreation: '2025-05-25'
  },
  {
    id: '2',
    nom: 'Présentation client TechnoSoft',
    description: 'Préparer la présentation des nouvelles fonctionnalités',
    clientId: '1',
    priorite: 'Haute',
    deadline: '2025-06-06',
    statut: 'À faire',
    dateCreation: '2025-06-03'
  },
  {
    id: '3',
    nom: 'Configuration hébergement',
    description: 'Configurer l\'hébergement pour StartUp Creative',
    clientId: '3',
    priorite: 'Moyenne',
    deadline: '2025-06-10',
    statut: 'À faire',
    dateCreation: '2025-06-02'
  },
  {
    id: '4',
    nom: 'Code review API REST',
    description: 'Révision du code API REST pour Consulting Plus',
    clientId: '4',
    priorite: 'Moyenne',
    deadline: '2025-06-12',
    statut: 'En cours',
    dateCreation: '2025-05-28'
  },
  {
    id: '5',
    nom: 'Documentation technique',
    description: 'Mise à jour documentation pour E-Commerce Solutions',
    clientId: '5',
    priorite: 'Basse',
    deadline: '2025-06-15',
    statut: 'À faire',
    dateCreation: '2025-05-30'
  },
  {
    id: '6',
    nom: 'Tests performance e-commerce',
    description: 'Test de performance de la plateforme e-learning',
    clientId: '5',
    priorite: 'Haute',
    deadline: '2025-06-07',
    statut: 'En cours',
    dateCreation: '2025-06-01'
  },
  {
    id: '7',
    nom: 'Formation équipe nouvelles techno',
    description: 'Formation équipe sur les nouvelles technologies',
    clientId: '7',
    priorite: 'Moyenne',
    deadline: '2025-06-20',
    statut: 'À faire',
    dateCreation: '2025-06-04'
  },
  {
    id: '8',
    nom: 'Backup données clients',
    description: 'Sauvegarde complète des données clients',
    clientId: '2',
    priorite: 'Haute',
    deadline: '2025-06-05',
    statut: 'Terminé',
    dateCreation: '2025-06-01'
  },
  {
    id: '9',
    nom: 'Analyse métriques mai',
    description: 'Analyse des métriques de performance de mai',
    clientId: '4',
    priorite: 'Basse',
    deadline: '2025-06-18',
    statut: 'À faire',
    dateCreation: '2025-06-03'
  },
  {
    id: '10',
    nom: 'Correction bugs app mobile',
    description: 'Correction des bugs critiques remontés en test',
    clientId: '8',
    priorite: 'Haute',
    deadline: '2025-06-02', // Tâche en retard
    statut: 'En cours',
    dateCreation: '2025-05-28'
  },
  {
    id: '11',
    nom: 'Mise en production',
    description: 'Déploiement de la nouvelle version en production',
    clientId: '9',
    priorite: 'Moyenne',
    deadline: '2025-06-14',
    statut: 'À faire',
    dateCreation: '2025-06-04'
  },
  {
    id: '12',
    nom: 'Contact client inactif',
    description: 'Relancer Marketing Pro pour renouveler le contrat',
    clientId: '6',
    priorite: 'Haute',
    deadline: '2025-06-01', // Tâche en retard
    statut: 'À faire',
    dateCreation: '2025-05-20'
  },
  {
    id: '13',
    nom: 'Optimisation base de données',
    description: 'Optimisation des performances de la base de données',
    clientId: '2',
    priorite: 'Moyenne',
    deadline: '2025-06-25',
    statut: 'À faire',
    dateCreation: '2025-06-04'
  }
];

// Historique étendu de dépenses sur 6 mois
export const mockDepenses: Depense[] = [
  // Mars 2025
  {
    id: '1',
    description: 'Ordinateurs portables équipe',
    montant: 2400,
    date: '2025-03-01',
    categorie: 'Matériel'
  },
  {
    id: '2',
    description: 'Licences Adobe Creative Suite',
    montant: 680,
    date: '2025-03-05',
    categorie: 'Logiciel'
  },
  {
    id: '3',
    description: 'Déplacement client Paris',
    montant: 320,
    date: '2025-03-10',
    categorie: 'Transport'
  },
  {
    id: '4',
    description: 'Abonnement téléphone professionnel',
    montant: 180,
    date: '2025-03-15',
    categorie: 'Communication'
  },
  
  // Avril 2025
  {
    id: '5',
    description: 'Écrans 4K pour développeurs',
    montant: 800,
    date: '2025-04-02',
    categorie: 'Matériel'
  },
  {
    id: '6',
    description: 'Serveur de sauvegarde',
    montant: 450,
    date: '2025-04-08',
    categorie: 'Matériel'
  },
  {
    id: '7',
    description: 'Licence Microsoft Office 365',
    montant: 300,
    date: '2025-04-12',
    categorie: 'Logiciel'
  },
  {
    id: '8',
    description: 'Formation sécurité informatique',
    montant: 850,
    date: '2025-04-18',
    categorie: 'Autre'
  },
  {
    id: '9',
    description: 'Mission Lyon client',
    montant: 280,
    date: '2025-04-22',
    categorie: 'Transport'
  },
  
  // Mai 2025
  {
    id: '10',
    description: 'Logiciel de gestion projet',
    montant: 420,
    date: '2025-05-03',
    categorie: 'Logiciel'
  },
  {
    id: '11',
    description: 'Internet fibre entreprise',
    montant: 120,
    date: '2025-05-05',
    categorie: 'Communication'
  },
  {
    id: '12',
    description: 'Assurance matériel informatique',
    montant: 380,
    date: '2025-05-12',
    categorie: 'Autre'
  }
];

// Dépenses de démonstration (utilise les données du fichier temporaire)
export const mockDepenses = mockDepensesCorrect;

// Alertes de démonstration
export const mockAlertes: Alerte[] = [
  {
    id: '1',
    type: 'tache-retard',
    titre: 'Tâche en retard',
    description: 'La tâche "Finaliser maquettes app mobile" pour InnovaTech Solutions est en retard depuis 2 jours',
    niveau: 'critique',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '1'
  },
  {
    id: '2',
    type: 'tache-retard',
    titre: 'Tâche critique en retard',
    description: 'La tâche "Correction bugs app mobile" pour InnovaTech Solutions est en retard depuis 3 jours',
    niveau: 'critique',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '2'
  },
  {
    id: '3',
    type: 'client-inactif',
    titre: 'Client inactif',
    description: 'Le client "Startup Innovation" n\'a eu aucun échange depuis plus de 60 jours',
    niveau: 'important',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '10'
  }
];

// Données principales
export const donneesDemo: DonneesBusiness = {
  clients: mockClients,
  ventes: mockVentes,
  taches: mockTaches,
  depenses: mockDepensesCorrect,
  alertes: mockAlertes
};

// Export par défaut (compatibilité)
export default donneesDemo;
  {
    id: '6',
    description: 'Équipement bureau',
    montant: 1400,
    date: '2025-01-15',
    categorie: 'Équipement'
  },
  
  // Février 2025
  {
    id: '7',
    description: 'Serveurs AWS',
    montant: 600,
    date: '2025-02-01',
    categorie: 'Infrastructure'
  },
  {
    id: '8',
    description: 'Assurance professionnelle',
    montant: 420,
    date: '2025-02-15',
    categorie: 'Assurance'
  },
  {
    id: '9',
    description: 'Publicité Google Ads',
    montant: 850,
    date: '2025-02-20',
    categorie: 'Marketing'
  },
  
  // Mars 2025
  {
    id: '10',
    description: 'Serveurs AWS',
    montant: 580,
    date: '2025-03-01',
    categorie: 'Infrastructure'
  },
  {
    id: '11',
    description: 'Licences logiciels',
    montant: 1200,
    date: '2025-03-15',
    categorie: 'Logiciels'
  },
  {
    id: '12',
    description: 'Formation équipe',
    montant: 2400,
    date: '2025-03-20',
    categorie: 'Formation'
  },
  
  // Avril 2025
  {
    id: '13',
    description: 'Serveurs AWS',
    montant: 620,
    date: '2025-04-01',
    categorie: 'Infrastructure'
  },
  {
    id: '14',
    description: 'Marketing digital',
    montant: 800,
    date: '2025-04-02',
    categorie: 'Marketing'
  },
  {
    id: '15',
    description: 'Équipement bureau',
    montant: 1500,
    date: '2025-04-10',
    categorie: 'Équipement'
  },
  {
    id: '16',
    description: 'Assurance professionnelle',
    montant: 450,
    date: '2025-04-15',
    categorie: 'Assurance'
  },
  
  // Mai 2025
  {
    id: '17',
    description: 'Serveurs AWS',
    montant: 590,
    date: '2025-05-01',
    categorie: 'Infrastructure'
  },
  {
    id: '18',
    description: 'Publicité Google Ads',
    montant: 950,
    date: '2025-05-05',
    categorie: 'Marketing'
  },
  {
    id: '19',
    description: 'Outils de développement',
    montant: 300,
    date: '2025-05-20',
    categorie: 'Logiciels'
  },
  {
    id: '20',
    description: 'Frais de déplacement',
    montant: 680,
    date: '2025-05-25',
    categorie: 'Déplacement'
  },
  
  // Juin 2025
  {
    id: '21',
    description: 'Serveurs AWS',
    montant: 610,
    date: '2025-06-01',
    categorie: 'Infrastructure'
  }
];

// Alertes de démonstration
export const mockAlertes: Alerte[] = [
  {
    id: '1',
    type: 'tache-retard',
    titre: 'Tâche en retard',
    description: 'La tâche "Finaliser maquettes app mobile" pour InnovaTech Solutions est en retard depuis 2 jours',
    niveau: 'critique',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '1'
  },
  {
    id: '2',
    type: 'tache-retard',
    titre: 'Tâche critique en retard',
    description: 'La tâche "Correction bugs app mobile" pour InnovaTech Solutions est en retard depuis 3 jours',
    niveau: 'critique',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '10'
  },
  {
    id: '3',
    type: 'tache-retard',
    titre: 'Tâche commerciale en retard',
    description: 'La tâche "Contact client inactif" pour Marketing Pro est en retard depuis 4 jours',
    niveau: 'important',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '12'
  },
  {
    id: '4',
    type: 'client-inactif',
    titre: 'Client inactif',
    description: 'Marketing Pro n\'a pas été contacté depuis 85 jours (dernier contact: 12/03/2025)',
    niveau: 'important',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '6'
  },
  {
    id: '5',
    type: 'client-inactif',
    titre: 'Client prospect inactif',
    description: 'InnovaTech Solutions n\'a pas été contacté depuis 18 jours (dernier contact: 18/05/2025)',
    niveau: 'info',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '8'
  },
  {
    id: '6',
    type: 'client-inactif',
    titre: 'Client inactif longue durée',
    description: 'WebDev Agency n\'a pas été contacté depuis 46 jours (dernier contact: 20/04/2025)',
    niveau: 'important',
    dateDetection: '2025-06-05',
    estTraitee: false,
    elementId: '9'
  }
];

export const mockData: DonneesBusiness = {
  clients: mockClients,
  ventes: mockVentes,
  taches: mockTaches,
  depenses: mockDepensesCorrect,
  alertes: mockAlertes
};
