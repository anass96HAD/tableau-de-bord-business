import { useState } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Plus, Edit2, Trash2, Euro } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Depense } from '@/types';

interface SuiviDepensesProps {
  depenses: Depense[];
  onAjouterDepense: (depense: Omit<Depense, 'id'>) => void;
  onModifierDepense: (id: string, depense: Partial<Depense>) => void;
  onSupprimerDepense: (id: string) => void;
}

const CATEGORIES_COULEURS = {
  'Matériel': 'bg-blue-100 text-blue-800',
  'Logiciel': 'bg-green-100 text-green-800', 
  'Transport': 'bg-orange-100 text-orange-800',
  'Communication': 'bg-purple-100 text-purple-800',
  'Autre': 'bg-gray-100 text-gray-800'
};

export function SuiviDepenses({ 
  depenses, 
  onAjouterDepense, 
  onModifierDepense, 
  onSupprimerDepense 
}: SuiviDepensesProps) {
  const { toast } = useToast();
  const [formulaireOuvert, setFormulaireOuvert] = useState(false);
  const [depenseEnEdition, setDepenseEnEdition] = useState<Depense | null>(null);
  
  // État du formulaire avec validation
  const [formData, setFormData] = useState({
    description: '',
    montant: '',
    date: '',
    categorie: '' as Depense['categorie'] | ''
  });

  const [erreurs, setErreurs] = useState<{[key: string]: string}>({});

  // Calculer le total des dépenses
  const totalDepenses = depenses.reduce((total, depense) => total + depense.montant, 0);

  const formatEuro = (montant: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    }).format(montant);
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'dd/MM/yyyy', { locale: fr });
  };

  const validerFormulaire = () => {
    const nouvellesErreurs: {[key: string]: string} = {};

    if (!formData.description.trim()) {
      nouvellesErreurs.description = 'Description requise';
    }

    const montant = parseFloat(formData.montant);
    if (!formData.montant || isNaN(montant) || montant <= 0) {
      nouvellesErreurs.montant = 'Montant doit être supérieur à 0';
    }

    if (!formData.date) {
      nouvellesErreurs.date = 'Date requise';
    }

    if (!formData.categorie) {
      nouvellesErreurs.categorie = 'Catégorie requise';
    }

    setErreurs(nouvellesErreurs);
    return Object.keys(nouvellesErreurs).length === 0;
  };

  const reinitialiserFormulaire = () => {
    setFormData({
      description: '',
      montant: '',
      date: '',
      categorie: ''
    });
    setErreurs({});
    setDepenseEnEdition(null);
  };

  const ouvrirFormulaireAjout = () => {
    reinitialiserFormulaire();
    setFormData(prev => ({
      ...prev,
      date: format(new Date(), 'yyyy-MM-dd')
    }));
    setFormulaireOuvert(true);
  };

  const ouvrirFormulaireEdition = (depense: Depense) => {
    setFormData({
      description: depense.description,
      montant: depense.montant.toString(),
      date: depense.date,
      categorie: depense.categorie
    });
    setDepenseEnEdition(depense);
    setFormulaireOuvert(true);
  };

  const sauvegarderDepense = () => {
    if (!validerFormulaire()) return;

    const donneesDepense = {
      description: formData.description.trim(),
      montant: parseFloat(formData.montant),
      date: formData.date,
      categorie: formData.categorie as Depense['categorie']
    };

    if (depenseEnEdition) {
      onModifierDepense(depenseEnEdition.id, donneesDepense);
      toast({
        title: "✅ Dépense modifiée",
        description: `La dépense "${donneesDepense.description}" a été mise à jour.`,
        duration: 3000,
      });
    } else {
      onAjouterDepense(donneesDepense);
      toast({
        title: "✅ Dépense ajoutée",
        description: `La dépense "${donneesDepense.description}" a été ajoutée.`,
        duration: 3000,
      });
    }

    setFormulaireOuvert(false);
    reinitialiserFormulaire();
  };

  const confirmerSuppression = (depense: Depense) => {
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer la dépense "${depense.description}" ?`)) {
      onSupprimerDepense(depense.id);
      toast({
        title: "🗑️ Dépense supprimée",
        description: `La dépense "${depense.description}" a été supprimée.`,
        duration: 3000,
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <Euro className="h-5 w-5 text-red-600" />
            💰 Gestion des Dépenses
          </CardTitle>
          <Button onClick={ouvrirFormulaireAjout}>
            <Plus className="h-4 w-4 mr-2" />
            Nouvelle Dépense
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Statistiques rapides */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600">{formatEuro(totalDepenses)}</p>
                <p className="text-sm text-muted-foreground">Total Dépenses</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{depenses.length}</p>
                <p className="text-sm text-muted-foreground">Nombre Dépenses</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">
                  {depenses.length > 0 ? formatEuro(totalDepenses / depenses.length) : '0 €'}
                </p>
                <p className="text-sm text-muted-foreground">Moyenne</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Formulaire d'ajout/édition */}
        {formulaireOuvert && (
          <Card className="mb-6 border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="text-lg">
                {depenseEnEdition ? 'Modifier la Dépense' : 'Nouvelle Dépense'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Description *</label>
                  <input
                    type="text"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
                    placeholder="Description de la dépense"
                  />
                  {erreurs.description && (
                    <p className="text-red-600 text-xs mt-1">{erreurs.description}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Montant (€) *</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.montant}
                    onChange={(e) => setFormData(prev => ({ ...prev, montant: e.target.value }))}
                    className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
                    placeholder="0.00"
                  />
                  {erreurs.montant && (
                    <p className="text-red-600 text-xs mt-1">{erreurs.montant}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Date *</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                    className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
                  />
                  {erreurs.date && (
                    <p className="text-red-600 text-xs mt-1">{erreurs.date}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Catégorie *</label>
                  <select
                    value={formData.categorie}
                    onChange={(e) => setFormData(prev => ({ ...prev, categorie: e.target.value as Depense['categorie'] }))}
                    className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Sélectionner une catégorie</option>
                    <option value="Matériel">Matériel</option>
                    <option value="Logiciel">Logiciel</option>
                    <option value="Transport">Transport</option>
                    <option value="Communication">Communication</option>
                    <option value="Autre">Autre</option>
                  </select>
                  {erreurs.categorie && (
                    <p className="text-red-600 text-xs mt-1">{erreurs.categorie}</p>
                  )}
                </div>
              </div>
              
              <div className="flex gap-2 mt-4">
                <Button onClick={sauvegarderDepense}>
                  {depenseEnEdition ? 'Modifier' : 'Ajouter'}
                </Button>
                <Button variant="outline" onClick={() => {
                  setFormulaireOuvert(false);
                  reinitialiserFormulaire();
                }}>
                  Annuler
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tableau des dépenses */}
        {depenses.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Aucune dépense enregistrée. Cliquez sur "Nouvelle Dépense" pour commencer.
          </div>
        ) : (
          <div className="space-y-3">
            {depenses
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
              .map((depense) => (
                <Card key={depense.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-medium">{depense.description}</h3>
                          <Badge className={CATEGORIES_COULEURS[depense.categorie]}>
                            {depense.categorie}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>{formatDate(depense.date)}</span>
                          <span className="font-medium text-red-600">
                            {formatEuro(depense.montant)}
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => ouvrirFormulaireEdition(depense)}
                        >
                          <Edit2 className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => confirmerSuppression(depense)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
