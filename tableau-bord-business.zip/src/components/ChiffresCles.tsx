import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, DollarSign, ShoppingCart, TrendingDown } from 'lucide-react';
import { ChiffresCles as ChiffresTypes } from '@/types';

interface ChiffresClesProps {
  donnees: ChiffresTypes[];
}

const COULEURS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

export function ChiffresCles({ donnees }: ChiffresClesProps) {
  // Derniers chiffres disponibles
  const dernierMois = donnees[0];
  
  // Données pour le graphique en barres (3 derniers mois)
  const donneesGraphique = donnees.slice(0, 3).reverse();

  // Données pour le camembert des dépenses par mois
  const donneesCamembert = donnees.slice(0, 3).map((item, index) => ({
    name: item.mois,
    value: item.depenses,
    fill: COULEURS[index]
  }));

  const formatEuro = (montant: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    }).format(montant);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* CA mensuel */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Chiffre d'Affaires</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {dernierMois ? formatEuro(dernierMois.ca) : '0 €'}
            </div>
            <p className="text-xs text-muted-foreground">
              {dernierMois?.mois || 'Aucune donnée'}
            </p>
          </CardContent>
        </Card>

        {/* Nombre de ventes */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Nombre de Ventes</CardTitle>
            <ShoppingCart className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {dernierMois?.nombreVentes || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Ventes confirmées
            </p>
          </CardContent>
        </Card>

        {/* Dépenses */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Dépenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {dernierMois ? formatEuro(dernierMois.depenses) : '0 €'}
            </div>
            <p className="text-xs text-muted-foreground">
              Frais mensuels
            </p>
          </CardContent>
        </Card>

        {/* Bénéfice */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bénéfice</CardTitle>
            <TrendingUp className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${dernierMois?.benefice >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {dernierMois ? formatEuro(dernierMois.benefice) : '0 €'}
            </div>
            <p className="text-xs text-muted-foreground">
              CA - Dépenses
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Graphiques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Graphique en barres */}
        <Card>
          <CardHeader>
            <CardTitle>Évolution Mensuelle</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={donneesGraphique}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="mois" />
                <YAxis tickFormatter={(value) => `${value / 1000}k€`} />
                <Tooltip 
                  formatter={(value: number, name: string) => [
                    formatEuro(value), 
                    name === 'ca' ? 'CA' : name === 'depenses' ? 'Dépenses' : 'Bénéfice'
                  ]}
                />
                <Bar dataKey="ca" fill="#3b82f6" name="ca" />
                <Bar dataKey="depenses" fill="#ef4444" name="depenses" />
                <Bar dataKey="benefice" fill="#10b981" name="benefice" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Graphique en camembert */}
        <Card>
          <CardHeader>
            <CardTitle>Répartition des Dépenses</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={donneesCamembert}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${formatEuro(value)}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {donneesCamembert.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatEuro(value)} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
