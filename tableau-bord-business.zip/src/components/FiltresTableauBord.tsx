import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Filter, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Filtres, Client } from '@/types';

interface FiltresTableauBordProps {
  filtres: Filtres;
  onChangerFiltres: (filtres: Filtres) => void;
  onReinitialiserFiltres: () => void;
  clients: Client[];
  moisDisponibles: string[];
}

export function FiltresTableauBord({ 
  filtres, 
  onChangerFiltres, 
  onReinitialiserFiltres, 
  clients,
  moisDisponibles 
}: FiltresTableauBordProps) {
  
  const mettreAJourFiltre = <K extends keyof Filtres>(cle: K, valeur: string | undefined) => {
    const nouveauxFiltres = { ...filtres };
    if (valeur && valeur !== '__all__') {
      (nouveauxFiltres as any)[cle] = valeur;
    } else {
      delete nouveauxFiltres[cle];
    }
    onChangerFiltres(nouveauxFiltres);
  };

  const obtenirNomMois = (moisAnnee: string) => {
    const [annee, mois] = moisAnnee.split('-');
    return format(new Date(parseInt(annee), parseInt(mois) - 1), 'MMMM yyyy', { locale: fr });
  };

  const compterFiltresActifs = () => {
    return Object.keys(filtres).length;
  };

  const obtenirNomClient = (clientId: string) => {
    const client = clients.find(c => c.id === clientId);
    return client ? client.nom : clientId;
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="flex items-center gap-2">
          <Filter className="h-5 w-5" />
          Filtres
          {compterFiltresActifs() > 0 && (
            <Badge variant="secondary">{compterFiltresActifs()}</Badge>
          )}
        </CardTitle>
        {compterFiltresActifs() > 0 && (
          <Button variant="outline" size="sm" onClick={onReinitialiserFiltres}>
            <X className="h-3 w-3 mr-1" />
            Réinitialiser
          </Button>
        )}
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* Filtre par mois */}
          <div className="space-y-2">
            <Label>Mois</Label>
            <Select 
              value={filtres.mois || '__all__'} 
              onValueChange={(value) => mettreAJourFiltre('mois', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Tous les mois" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">Tous les mois</SelectItem>
                {moisDisponibles.map((mois) => (
                  <SelectItem key={mois} value={mois}>
                    {obtenirNomMois(mois)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par client */}
          <div className="space-y-2">
            <Label>Client</Label>
            <Select 
              value={filtres.clientId || '__all__'} 
              onValueChange={(value) => mettreAJourFiltre('clientId', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Tous les clients" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">Tous les clients</SelectItem>
                {clients.map((client) => (
                  <SelectItem key={client.id} value={client.id}>
                    {client.nom}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par statut client */}
          <div className="space-y-2">
            <Label>Statut Client</Label>
            <Select 
              value={filtres.statutClient || '__all__'} 
              onValueChange={(value) => mettreAJourFiltre('statutClient', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Tous les statuts" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">Tous les statuts</SelectItem>
                <SelectItem value="Prospect">Prospect</SelectItem>
                <SelectItem value="Client">Client</SelectItem>
                <SelectItem value="Inactif">Inactif</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par statut vente */}
          <div className="space-y-2">
            <Label>Statut Vente</Label>
            <Select 
              value={filtres.statutVente || '__all__'} 
              onValueChange={(value) => mettreAJourFiltre('statutVente', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Tous les statuts" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">Tous les statuts</SelectItem>
                <SelectItem value="En cours">En cours</SelectItem>
                <SelectItem value="Confirmée">Confirmée</SelectItem>
                <SelectItem value="Annulée">Annulée</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par statut tâche */}
          <div className="space-y-2">
            <Label>Statut Tâche</Label>
            <Select 
              value={filtres.statutTache || '__all__'} 
              onValueChange={(value) => mettreAJourFiltre('statutTache', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Tous les statuts" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">Tous les statuts</SelectItem>
                <SelectItem value="À faire">À faire</SelectItem>
                <SelectItem value="En cours">En cours</SelectItem>
                <SelectItem value="Terminée">Terminée</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Affichage des filtres actifs */}
        {compterFiltresActifs() > 0 && (
          <div className="mt-4 pt-4 border-t">
            <div className="flex flex-wrap gap-2">
              <span className="text-sm text-muted-foreground">Filtres actifs:</span>
              {filtres.mois && (
                <Badge variant="outline" className="flex items-center gap-1">
                  Mois: {obtenirNomMois(filtres.mois)}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => mettreAJourFiltre('mois', undefined)}
                  />
                </Badge>
              )}
              {filtres.clientId && (
                <Badge variant="outline" className="flex items-center gap-1">
                  Client: {obtenirNomClient(filtres.clientId)}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => mettreAJourFiltre('clientId', undefined)}
                  />
                </Badge>
              )}
              {filtres.statutClient && (
                <Badge variant="outline" className="flex items-center gap-1">
                  Statut Client: {filtres.statutClient}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => mettreAJourFiltre('statutClient', undefined)}
                  />
                </Badge>
              )}
              {filtres.statutVente && (
                <Badge variant="outline" className="flex items-center gap-1">
                  Statut Vente: {filtres.statutVente}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => mettreAJourFiltre('statutVente', undefined)}
                  />
                </Badge>
              )}
              {filtres.statutTache && (
                <Badge variant="outline" className="flex items-center gap-1">
                  Statut Tâche: {filtres.statutTache}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => mettreAJourFiltre('statutTache', undefined)}
                  />
                </Badge>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
