import { useState } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Plus, Edit2, Trash2, User, Mail, Phone } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Client } from '@/types';

interface SuiviClientsProps {
  clients: Client[];
  onAjouterClient: (client: Omit<Client, 'id'>) => void;
  onModifierClient: (id: string, client: Partial<Client>) => void;
  onSupprimerClient: (id: string) => void;
}

const STATUTS_COULEURS = {
  'Prospect': 'bg-yellow-100 text-yellow-800',
  'Client': 'bg-green-100 text-green-800',
  'Inactif': 'bg-gray-100 text-gray-800',
};

export function SuiviClients({ clients, onAjouterClient, onModifierClient, onSupprimerClient }: SuiviClientsProps) {
  const [dialogOuvert, setDialogOuvert] = useState(false);
  const [clientEnEdition, setClientEnEdition] = useState<Client | null>(null);
  const [formData, setFormData] = useState({
    nom: '',
    email: '',
    telephone: '',
    statut: 'Prospect' as Client['statut']
  });

  const resetForm = () => {
    setFormData({
      nom: '',
      email: '',
      telephone: '',
      statut: 'Prospect'
    });
    setClientEnEdition(null);
  };

  const ouvrirDialogAjout = () => {
    resetForm();
    setDialogOuvert(true);
  };

  const ouvrirDialogEdition = (client: Client) => {
    setClientEnEdition(client);
    setFormData({
      nom: client.nom,
      email: client.email,
      telephone: client.telephone,
      statut: client.statut
    });
    setDialogOuvert(true);
  };

  const sauvegarderClient = () => {
    if (!formData.nom || !formData.email) return;

    if (clientEnEdition) {
      onModifierClient(clientEnEdition.id, {
        ...formData,
        dateDernierEchange: new Date().toISOString().split('T')[0]
      });
    } else {
      onAjouterClient({
        ...formData,
        dateDernierEchange: new Date().toISOString().split('T')[0],
        dateCreation: new Date().toISOString().split('T')[0]
      });
    }

    setDialogOuvert(false);
    resetForm();
  };

  const confirmerSuppression = (client: Client) => {
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer le client "${client.nom}" ?`)) {
      onSupprimerClient(client.id);
    }
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'dd/MM/yyyy', { locale: fr });
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <User className="h-5 w-5" />
          Suivi des Clients ({clients.length})
        </CardTitle>
        <Dialog open={dialogOuvert} onOpenChange={setDialogOuvert}>
          <DialogTrigger asChild>
            <Button onClick={ouvrirDialogAjout} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Nouveau Client
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {clientEnEdition ? 'Modifier le Client' : 'Nouveau Client'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="nom">Nom du client</Label>
                <Input
                  id="nom"
                  value={formData.nom}
                  onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
                  placeholder="Ex: TechnoSoft SARL"
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="contact@exemple.fr"
                />
              </div>
              <div>
                <Label htmlFor="telephone">Téléphone</Label>
                <Input
                  id="telephone"
                  value={formData.telephone}
                  onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
                  placeholder="01 23 45 67 89"
                />
              </div>
              <div>
                <Label htmlFor="statut">Statut</Label>
                <Select value={formData.statut} onValueChange={(value: Client['statut']) => setFormData({ ...formData, statut: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Prospect">Prospect</SelectItem>
                    <SelectItem value="Client">Client</SelectItem>
                    <SelectItem value="Inactif">Inactif</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setDialogOuvert(false)}>
                  Annuler
                </Button>
                <Button onClick={sauvegarderClient}>
                  {clientEnEdition ? 'Modifier' : 'Ajouter'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {clients.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Aucun client trouvé
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-4">Nom</th>
                  <th className="text-left py-2 px-4">Contact</th>
                  <th className="text-left py-2 px-4">Statut</th>
                  <th className="text-left py-2 px-4">Dernier Échange</th>
                  <th className="text-left py-2 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {clients.map((client) => (
                  <tr key={client.id} className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium">{client.nom}</td>
                    <td className="py-3 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="h-3 w-3" />
                          <a href={`mailto:${client.email}`} className="text-blue-600 hover:underline">
                            {client.email}
                          </a>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-3 w-3" />
                          <a href={`tel:${client.telephone}`} className="hover:underline">
                            {client.telephone}
                          </a>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge className={STATUTS_COULEURS[client.statut]}>
                        {client.statut}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-sm">
                      {formatDate(client.dateDernierEchange)}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => ouvrirDialogEdition(client)}
                        >
                          <Edit2 className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => confirmerSuppression(client)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
