import { useState } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TrendingUp, DollarSign, ShoppingCart, TrendingDown, Calendar, Users } from 'lucide-react';
import { StatistiquesAvancees, ChiffresCles } from '@/types';

interface ChiffresClesAvancesProps {
  statistiques: StatistiquesAvancees;
  chiffresCles: ChiffresCles[];
}

const COULEURS_GRAPHIQUES = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316'];

export function ChiffresClesAvances({ statistiques, chiffresCles }: ChiffresClesAvancesProps) {
  const [moisSelectionne, setMoisSelectionne] = useState(
    chiffresCles.length > 0 ? format(new Date(), 'yyyy-MM') : '2025-05'
  );
  
  // Obtenir les données du mois sélectionné
  const donneesMois = chiffresCles.find(c => 
    format(new Date(c.mois + '-01'), 'yyyy-MM') === moisSelectionne
  ) || chiffresCles[0];

  // Données pour le graphique en barres (évolution mensuelle)
  const donneesEvolution = statistiques.evolutionSurSixMois;

  // Données pour le graphique en camembert (répartition CA par client)
  const donneesCAParClient = statistiques.derniersStatistiques[0]?.ventesParClient || [];
  const donneesCAAvecCouleurs = donneesCAParClient.map((item, index) => ({
    ...item,
    fill: COULEURS_GRAPHIQUES[index % COULEURS_GRAPHIQUES.length]
  }));

  // Données pour le graphique linéaire (tendance des ventes)
  const donneesTendanceVentes = chiffresCles.slice(0, 6).reverse();

  const formatEuro = (montant: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    }).format(montant);
  };

  const formatMoisSelect = (moisAnnee: string) => {
    const [annee, mois] = moisAnnee.split('-');
    return format(new Date(parseInt(annee), parseInt(mois) - 1), 'MMMM yyyy', { locale: fr });
  };

  // Mois disponibles pour le sélecteur (sans doublons)
  const moisDisponibles = [...new Set(chiffresCles.slice(0, 6).map(c => 
    format(new Date(c.mois + '-01'), 'yyyy-MM')
  ))].sort().reverse();

  return (
    <div className="space-y-6">
      {/* Sélecteur de mois */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Analyse Mensuelle
            </CardTitle>
            <Select value={moisSelectionne} onValueChange={setMoisSelectionne}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {moisDisponibles.map((mois) => (
                  <SelectItem key={mois} value={mois}>
                    {formatMoisSelect(mois)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
      </Card>

      {/* Cartes métriques pour le mois sélectionné */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Chiffre d'Affaires</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {donneesMois ? formatEuro(donneesMois.ca) : '0 €'}
            </div>
            <p className="text-xs text-muted-foreground">
              {donneesMois?.mois || 'Aucune donnée'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Nombre de Ventes</CardTitle>
            <ShoppingCart className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {donneesMois?.nombreVentes || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Ventes confirmées
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Dépenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {donneesMois ? formatEuro(donneesMois.depenses) : '0 €'}
            </div>
            <p className="text-xs text-muted-foreground">
              Frais du mois
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bénéfice</CardTitle>
            <TrendingUp className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${donneesMois?.benefice >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {donneesMois ? formatEuro(donneesMois.benefice) : '0 €'}
            </div>
            <p className="text-xs text-muted-foreground">
              CA - Dépenses
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Graphiques avancés */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Évolution mensuelle (6 mois) */}
        <Card>
          <CardHeader>
            <CardTitle>Évolution sur 6 Mois</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={donneesEvolution}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="mois" 
                  tickFormatter={(value) => format(new Date(value + '-01'), 'MMM', { locale: fr })}
                />
                <YAxis tickFormatter={(value) => `${value / 1000}k€`} />
                <Tooltip 
                  formatter={(value: number, name: string) => [
                    formatEuro(value), 
                    name === 'ca' ? 'CA' : name === 'depenses' ? 'Dépenses' : 'Bénéfice'
                  ]}
                  labelFormatter={(label) => format(new Date(label + '-01'), 'MMMM yyyy', { locale: fr })}
                />
                <Bar dataKey="ca" fill="#3b82f6" name="ca" />
                <Bar dataKey="depenses" fill="#ef4444" name="depenses" />
                <Bar dataKey="benefice" fill="#10b981" name="benefice" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Répartition CA par client */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              CA par Client ({formatMoisSelect(moisSelectionne)})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {donneesCAAvecCouleurs.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={donneesCAAvecCouleurs}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ clientNom, montant, percent }) => 
                      `${clientNom}: ${formatEuro(montant)} (${(percent * 100).toFixed(0)}%)`
                    }
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="montant"
                  >
                    {donneesCAAvecCouleurs.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatEuro(value)} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-muted-foreground">
                Aucune vente confirmée ce mois-ci
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Graphique de tendance des ventes */}
      <Card>
        <CardHeader>
          <CardTitle>Tendance des Ventes (6 derniers mois)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={donneesTendanceVentes}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="mois" 
                tickFormatter={(value) => format(new Date(value + '-01'), 'MMM yyyy', { locale: fr })}
              />
              <YAxis 
                yAxisId="ca"
                orientation="left"
                tickFormatter={(value) => `${value / 1000}k€`}
              />
              <YAxis 
                yAxisId="ventes"
                orientation="right"
                tickFormatter={(value) => `${value}`}
              />
              <Tooltip 
                formatter={(value: number, name: string) => [
                  name === 'ca' ? formatEuro(value) : `${value} ventes`,
                  name === 'ca' ? 'Chiffre d\'Affaires' : 'Nombre de Ventes'
                ]}
                labelFormatter={(label) => format(new Date(label + '-01'), 'MMMM yyyy', { locale: fr })}
              />
              <Line 
                yAxisId="ca"
                type="monotone" 
                dataKey="ca" 
                stroke="#3b82f6" 
                strokeWidth={3}
                name="ca"
                dot={{ r: 6 }}
              />
              <Line 
                yAxisId="ventes"
                type="monotone" 
                dataKey="nombreVentes" 
                stroke="#10b981" 
                strokeWidth={3}
                name="ventes"
                dot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Résumé des performances */}
      <Card>
        <CardHeader>
          <CardTitle>Résumé des Performances</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">
                {donneesEvolution.reduce((sum, m) => sum + m.ca, 0) / 1000}k€
              </div>
              <div className="text-sm text-muted-foreground">CA Total 6 mois</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">
                {donneesEvolution.reduce((sum, m) => sum + m.nombreVentes, 0)}
              </div>
              <div className="text-sm text-muted-foreground">Ventes Total 6 mois</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600">
                {donneesEvolution.reduce((sum, m) => sum + m.depenses, 0) / 1000}k€
              </div>
              <div className="text-sm text-muted-foreground">Dépenses Total 6 mois</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">
                {donneesEvolution.reduce((sum, m) => sum + m.benefice, 0) / 1000}k€
              </div>
              <div className="text-sm text-muted-foreground">Bénéfice Total 6 mois</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
