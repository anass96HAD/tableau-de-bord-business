import { useEffect } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Bell, AlertTriangle, Clock, Info, CheckSquare, X, MoreVertical } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Alerte } from '@/types';

interface AlertesTableauBordProps {
  alertes: Alerte[];
  alertesDetectees: Omit<Alerte, 'id'>[];
  onMarquerCommeTraitee: (id: string) => void;
  onSnoozer: (id: string, duree?: number) => void;
  onSupprimerAlerte: (id: string) => void;
  onAjouterAlerte: (alerte: Omit<Alerte, 'id'>) => void;
}

const ICONES_NIVEAU = {
  'critique': AlertTriangle,
  'important': Clock,
  'info': Info,
};

const COULEURS_NIVEAU = {
  'critique': 'bg-red-100 text-red-800 border-red-200',
  'important': 'bg-orange-100 text-orange-800 border-orange-200',
  'info': 'bg-blue-100 text-blue-800 border-blue-200',
};

const COULEURS_ICONE = {
  'critique': 'text-red-600',
  'important': 'text-orange-600',
  'info': 'text-blue-600',
};

export function AlertesTableauBord({ 
  alertes, 
  alertesDetectees,
  onMarquerCommeTraitee, 
  onSnoozer, 
  onSupprimerAlerte,
  onAjouterAlerte 
}: AlertesTableauBordProps) {
  const { toast } = useToast();
  
  // Utiliser useEffect pour ajouter les alertes détectées automatiquement (contrôlé)
  useEffect(() => {
    // N'ajouter que les nouvelles alertes qui n'existent pas déjà
    alertesDetectees.forEach(alerteDetectee => {
      const alerteExiste = alertes.some(a => 
        a.type === alerteDetectee.type && 
        a.elementId === alerteDetectee.elementId
      );
      if (!alerteExiste) {
        onAjouterAlerte(alerteDetectee);
      }
    });
  }, [alertesDetectees.length, alertes.length]); // Surveiller les changements

  // Fonctions avec feedbacks visuels
  const traiterAlerteAvecFeedback = (id: string, titre: string) => {
    onMarquerCommeTraitee(id);
    toast({
      title: "✅ Alerte traitée",
      description: `L'alerte "${titre}" a été marquée comme traitée.`,
      duration: 3000,
    });
  };

  const supprimerAlerteAvecFeedback = (id: string, titre: string) => {
    onSupprimerAlerte(id);
    toast({
      title: "🗑️ Alerte supprimée",
      description: `L'alerte "${titre}" a été supprimée définitivement.`,
      duration: 3000,
    });
  };

  const snoozerAlerteAvecFeedback = (id: string, duree: number, titre: string) => {
    onSnoozer(id, duree);
    const dureeTexte = duree === 1 ? '1 heure' : duree === 24 ? '24 heures' : '1 semaine';
    toast({
      title: "⏰ Alerte reportée",
      description: `L'alerte "${titre}" a été reportée de ${dureeTexte}.`,
      duration: 3000,
    });
  };

  const alertesArray = Array.isArray(alertes) ? alertes : [];
  
  // Filtrer d'abord les alertes non traitées et non en sommeil
  const maintenantDate = new Date();
  const alertesActives = alertesArray.filter(alerte => 
    !alerte.estTraitee && 
    (!alerte.dateMiseEnSommeil || new Date(alerte.dateMiseEnSommeil) < maintenantDate)
  );
  
  const alertesOrdonnees = [...alertesActives].sort((a, b) => {
    // Tri par niveau de priorité puis par date
    const priorite = { 'critique': 3, 'important': 2, 'info': 1 };
    if (priorite[a.niveau] !== priorite[b.niveau]) {
      return priorite[b.niveau] - priorite[a.niveau];
    }
    return new Date(b.dateDetection).getTime() - new Date(a.dateDetection).getTime();
  });

  const nombreAlertesActives = alertesActives.length;

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'dd/MM/yyyy', { locale: fr });
  };

  const obtenirTempsEcoule = (dateString: string) => {
    const maintenant = new Date();
    const dateAlerte = new Date(dateString);
    const diffHeures = Math.floor((maintenant.getTime() - dateAlerte.getTime()) / (1000 * 60 * 60));
    
    if (diffHeures < 1) return 'Il y a moins d\'1h';
    if (diffHeures < 24) return `Il y a ${diffHeures}h`;
    const diffJours = Math.floor(diffHeures / 24);
    return `Il y a ${diffJours} jour${diffJours > 1 ? 's' : ''}`;
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-orange-600" />
          🔔 Alertes du Jour
          {nombreAlertesActives > 0 && (
            <Badge variant="destructive" className="ml-2">
              {nombreAlertesActives}
            </Badge>
          )}
        </CardTitle>
        <div className="text-sm text-muted-foreground">
          Dernière vérification: {format(new Date(), 'HH:mm', { locale: fr })}
        </div>
      </CardHeader>
      <CardContent>
        {alertesActives.length === 0 ? (
          <Alert className="border-green-200 bg-green-50">
            <CheckSquare className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              🎉 Excellent ! Aucune alerte active. Votre business fonctionne parfaitement.
            </AlertDescription>
          </Alert>
        ) : (
          <div className="space-y-3">
            {alertesOrdonnees.map((alerte) => {
              const IconeNiveau = ICONES_NIVEAU[alerte.niveau];
              
              return (
                <Card 
                  key={alerte.id} 
                  className={`${COULEURS_NIVEAU[alerte.niveau]} ${alerte.estTraitee ? 'opacity-60' : ''}`}
                >
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="flex-shrink-0">
                          <IconeNiveau className={`h-5 w-5 ${COULEURS_ICONE[alerte.niveau]}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-sm">{alerte.titre}</h3>
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${COULEURS_NIVEAU[alerte.niveau]}`}
                            >
                              {alerte.niveau}
                            </Badge>
                            {alerte.estTraitee && (
                              <Badge variant="outline" className="text-xs bg-green-100 text-green-800">
                                Traitée
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-700 mb-2">{alerte.description}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Détectée: {formatDate(alerte.dateDetection)}</span>
                            <span>{obtenirTempsEcoule(alerte.dateDetection)}</span>
                            {alerte.dateMiseEnSommeil && (
                              <span>Rappel: {formatDate(alerte.dateMiseEnSommeil)}</span>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      {!alerte.estTraitee && (
                        <div className="flex items-center gap-2 ml-4">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => traiterAlerteAvecFeedback(alerte.id, alerte.titre)}
                            className="text-green-600 hover:text-green-700"
                          >
                            <CheckSquare className="h-3 w-3 mr-1" />
                            Traiter
                          </Button>
                          
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="outline" size="sm">
                                <MoreVertical className="h-3 w-3" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => snoozerAlerteAvecFeedback(alerte.id, 1, alerte.titre)}>
                                <Clock className="h-3 w-3 mr-2" />
                                Snoozer 1h
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => snoozerAlerteAvecFeedback(alerte.id, 24, alerte.titre)}>
                                <Clock className="h-3 w-3 mr-2" />
                                Snoozer 24h
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => snoozerAlerteAvecFeedback(alerte.id, 168, alerte.titre)}>
                                <Clock className="h-3 w-3 mr-2" />
                                Snoozer 1 semaine
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                onClick={() => supprimerAlerteAvecFeedback(alerte.id, alerte.titre)}
                                className="text-red-600"
                              >
                                <X className="h-3 w-3 mr-2" />
                                Supprimer
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
        
        {/* Résumé des alertes */}
        {alertesActives.length > 0 && (
          <div className="mt-6 pt-4 border-t">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-red-600">
                  {alertesActives.filter(a => a.niveau === 'critique').length}
                </div>
                <div className="text-sm text-muted-foreground">Critiques</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-orange-600">
                  {alertesActives.filter(a => a.niveau === 'important').length}
                </div>
                <div className="text-sm text-muted-foreground">Importantes</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600">
                  {alertesActives.filter(a => a.niveau === 'info').length}
                </div>
                <div className="text-sm text-muted-foreground">Informatives</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
