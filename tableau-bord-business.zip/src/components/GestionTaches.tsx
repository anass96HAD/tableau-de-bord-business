import { useState, useMemo } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Plus, Edit2, Trash2, CheckSquare, Clock, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tache, Client } from '@/types';

interface GestionTachesProps {
  taches: Tache[];
  clients: Client[];
  onAjouterTache: (tache: Omit<Tache, 'id'>) => void;
  onModifierTache: (id: string, tache: Partial<Tache>) => void;
  onSupprimerTache: (id: string) => void;
  obtenirNomClient: (clientId: string) => string;
}

const PRIORITES_COULEURS = {
  'Haute': 'bg-red-100 text-red-800',
  'Moyenne': 'bg-orange-100 text-orange-800',
  'Basse': 'bg-green-100 text-green-800',
};

const STATUTS_COULEURS = {
  'À faire': 'bg-gray-100 text-gray-800',
  'En cours': 'bg-blue-100 text-blue-800',
  'Terminé': 'bg-green-100 text-green-800',
};

const ICONES_PRIORITE = {
  'Haute': AlertTriangle,
  'Moyenne': Clock,
  'Basse': CheckSquare,
};

export function GestionTaches({ taches, clients, onAjouterTache, onModifierTache, onSupprimerTache, obtenirNomClient }: GestionTachesProps) {
  const [dialogOuvert, setDialogOuvert] = useState(false);
  const [tacheEnEdition, setTacheEnEdition] = useState<Tache | null>(null);
  const [triPar, setTriPar] = useState<'priorite' | 'deadline' | 'statut'>('deadline');
  const [formData, setFormData] = useState({
    nom: '',
    description: '',
    clientId: '',
    priorite: 'Moyenne' as Tache['priorite'],
    deadline: '',
    statut: 'À faire' as Tache['statut']
  });

  const resetForm = () => {
    setFormData({
      nom: '',
      description: '',
      clientId: '',
      priorite: 'Moyenne',
      deadline: '',
      statut: 'À faire'
    });
    setTacheEnEdition(null);
  };

  const ouvrirDialogAjout = () => {
    resetForm();
    setDialogOuvert(true);
  };

  const ouvrirDialogEdition = (tache: Tache) => {
    setTacheEnEdition(tache);
    setFormData({
      nom: tache.nom,
      description: tache.description || '',
      clientId: tache.clientId,
      priorite: tache.priorite,
      deadline: tache.deadline,
      statut: tache.statut
    });
    setDialogOuvert(true);
  };

  const sauvegarderTache = () => {
    if (!formData.nom || !formData.clientId || !formData.deadline) return;

    const tacheData = {
      nom: formData.nom,
      description: formData.description,
      clientId: formData.clientId,
      priorite: formData.priorite,
      deadline: formData.deadline,
      statut: formData.statut,
      dateCreation: new Date().toISOString().split('T')[0]
    };

    if (tacheEnEdition) {
      onModifierTache(tacheEnEdition.id, tacheData);
    } else {
      onAjouterTache(tacheData);
    }

    setDialogOuvert(false);
    resetForm();
  };

  const confirmerSuppression = (tache: Tache) => {
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer la tâche "${tache.nom}" ?`)) {
      onSupprimerTache(tache.id);
    }
  };

  const changerStatutRapide = (tache: Tache, nouveauStatut: Tache['statut']) => {
    onModifierTache(tache.id, { statut: nouveauStatut });
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'dd/MM/yyyy', { locale: fr });
  };

  const estEnRetard = (deadline: string) => {
    return new Date(deadline) < new Date() && new Date(deadline).toDateString() !== new Date().toDateString();
  };

  // Tri des tâches
  const tachesTriees = useMemo(() => {
    const tachesCopie = [...taches];
    
    switch (triPar) {
      case 'priorite':
        return tachesCopie.sort((a, b) => {
          const priorites = { 'Haute': 3, 'Moyenne': 2, 'Basse': 1 };
          return priorites[b.priorite] - priorites[a.priorite];
        });
      case 'deadline':
        return tachesCopie.sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime());
      case 'statut':
        return tachesCopie.sort((a, b) => {
          const statuts = { 'À faire': 1, 'En cours': 2, 'Terminé': 3 };
          return statuts[a.statut] - statuts[b.statut];
        });
      default:
        return tachesCopie;
    }
  }, [taches, triPar]);

  // Statistiques des tâches
  const statistiques = useMemo(() => {
    const total = taches.length;
    const terminees = taches.filter(t => t.statut === 'Terminé').length;
    const enCours = taches.filter(t => t.statut === 'En cours').length;
    const enRetard = taches.filter(t => t.statut !== 'Terminé' && estEnRetard(t.deadline)).length;
    
    return { total, terminees, enCours, enRetard };
  }, [taches]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <CheckSquare className="h-5 w-5" />
          Gestion des Tâches ({taches.length})
        </CardTitle>
        <Dialog open={dialogOuvert} onOpenChange={setDialogOuvert}>
          <DialogTrigger asChild>
            <Button onClick={ouvrirDialogAjout} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Nouvelle Tâche
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {tacheEnEdition ? 'Modifier la Tâche' : 'Nouvelle Tâche'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="nom">Nom de la tâche *</Label>
                <Input
                  id="nom"
                  value={formData.nom}
                  onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
                  placeholder="Ex: Finaliser maquettes app mobile"
                />
              </div>
              <div>
                <Label htmlFor="clientId">Client associé *</Label>
                <Select value={formData.clientId} onValueChange={(value) => setFormData({ ...formData, clientId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner un client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id}>
                        {client.nom}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="description">Description (optionnel)</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Détails supplémentaires sur la tâche..."
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="priorite">Priorité</Label>
                  <Select value={formData.priorite} onValueChange={(value: Tache['priorite']) => setFormData({ ...formData, priorite: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Haute">Haute</SelectItem>
                      <SelectItem value="Moyenne">Moyenne</SelectItem>
                      <SelectItem value="Basse">Basse</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="statut">Statut</Label>
                  <Select value={formData.statut} onValueChange={(value: Tache['statut']) => setFormData({ ...formData, statut: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="À faire">À faire</SelectItem>
                      <SelectItem value="En cours">En cours</SelectItem>
                      <SelectItem value="Terminé">Terminé</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="deadline">Échéance</Label>
                <Input
                  id="deadline"
                  type="date"
                  value={formData.deadline}
                  onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setDialogOuvert(false)}>
                  Annuler
                </Button>
                <Button onClick={sauvegarderTache}>
                  {tacheEnEdition ? 'Modifier' : 'Ajouter'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {/* Statistiques */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{statistiques.total}</p>
                <p className="text-sm text-muted-foreground">Total</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{statistiques.terminees}</p>
                <p className="text-sm text-muted-foreground">Terminées</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-orange-600">{statistiques.enCours}</p>
                <p className="text-sm text-muted-foreground">En cours</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600">{statistiques.enRetard}</p>
                <p className="text-sm text-muted-foreground">En retard</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contrôles de tri */}
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2">
            <Label>Trier par:</Label>
            <Select value={triPar} onValueChange={(value: 'priorite' | 'deadline' | 'statut') => setTriPar(value)}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="deadline">Échéance</SelectItem>
                <SelectItem value="priorite">Priorité</SelectItem>
                <SelectItem value="statut">Statut</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Liste des tâches */}
        {tachesTriees.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Aucune tâche trouvée
          </div>
        ) : (
          <div className="space-y-3">
            {tachesTriees.map((tache) => {
              const IconePriorite = ICONES_PRIORITE[tache.priorite];
              const enRetard = estEnRetard(tache.deadline) && tache.statut !== 'Terminé';
              
              return (
                <Card key={tache.id} className={`${enRetard ? 'border-red-200 bg-red-50' : ''}`}>
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <IconePriorite className={`h-4 w-4 ${
                            tache.priorite === 'Haute' ? 'text-red-600' :
                            tache.priorite === 'Moyenne' ? 'text-orange-600' : 'text-green-600'
                          }`} />
                          <div className="flex-1">
                            <h3 className={`font-medium ${tache.statut === 'Terminé' ? 'line-through text-muted-foreground' : ''}`}>
                              {tache.nom}
                            </h3>
                            <p className="text-sm text-muted-foreground mt-1">
                              Client: {obtenirNomClient(tache.clientId)}
                            </p>
                            {tache.description && (
                              <p className="text-sm text-gray-600 mt-1">{tache.description}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <Badge className={PRIORITES_COULEURS[tache.priorite]}>
                            {tache.priorite}
                          </Badge>
                          <Badge className={STATUTS_COULEURS[tache.statut]}>
                            {tache.statut}
                          </Badge>
                          <span className={`flex items-center gap-1 ${enRetard ? 'text-red-600 font-medium' : 'text-muted-foreground'}`}>
                            <Clock className="h-3 w-3" />
                            {formatDate(tache.deadline)}
                            {enRetard && ' (En retard)'}
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        {tache.statut !== 'Terminé' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => changerStatutRapide(tache, 'Terminé')}
                            className="text-green-600 hover:text-green-700"
                          >
                            <CheckSquare className="h-3 w-3" />
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => ouvrirDialogEdition(tache)}
                        >
                          <Edit2 className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => confirmerSuppression(tache)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
