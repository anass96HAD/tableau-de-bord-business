import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tache, Client } from '@/types';

interface GestionTachesProps {
  taches: Tache[];
  clients: Client[];
  onAjouterTache: (tache: Omit<Tache, 'id'>) => void;
  onModifierTache: (id: string, tache: Partial<Tache>) => void;
  onSupprimerTache: (id: string) => void;
  obtenirNomClient: (clientId: string) => string;
}

export function GestionTaches({ taches, clients, onAjouterTache, onModifierTache, onSupprimerTache, obtenirNomClient }: GestionTachesProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Gestion des Tâches</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {taches.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Aucune tâche trouvée
            </div>
          ) : (
            <div className="space-y-3">
              {taches.map((tache) => (
                <Card key={tache.id}>
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium">{tache.nom}</h3>
                        <p className="text-sm text-muted-foreground">
                          Client: {obtenirNomClient(tache.clientId)}
                        </p>
                        <p className="text-sm text-gray-600">{tache.description}</p>
                        <div className="flex gap-2 mt-2">
                          <span className="text-sm px-2 py-1 bg-blue-100 text-blue-800 rounded">
                            {tache.priorite}
                          </span>
                          <span className="text-sm px-2 py-1 bg-green-100 text-green-800 rounded">
                            {tache.statut}
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onModifierTache(tache.id, { statut: 'Terminé' })}
                        >
                          Terminer
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onSupprimerTache(tache.id)}
                          className="text-red-600"
                        >
                          Supprimer
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
