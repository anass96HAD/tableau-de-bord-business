import { useState, useMemo } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Plus, Edit2, Trash2, ShoppingBag, Calculator } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Vente, Client } from '@/types';

interface SuiviVentesProps {
  ventes: Vente[];
  clients: Client[];
  onAjouterVente: (vente: Omit<Vente, 'id'>) => void;
  onModifierVente: (id: string, vente: Partial<Vente>) => void;
  onSupprimerVente: (id: string) => void;
  obtenirNomClient: (clientId: string) => string;
}

const STATUTS_COULEURS = {
  'En cours': 'bg-blue-100 text-blue-800',
  'Confirmée': 'bg-green-100 text-green-800',
  'Annulée': 'bg-red-100 text-red-800',
};

export function SuiviVentes({ 
  ventes, 
  clients, 
  onAjouterVente, 
  onModifierVente, 
  onSupprimerVente, 
  obtenirNomClient 
}: SuiviVentesProps) {
  const [dialogOuvert, setDialogOuvert] = useState(false);
  const [venteEnEdition, setVenteEnEdition] = useState<Vente | null>(null);
  const [formData, setFormData] = useState({
    produitService: '',
    montant: '',
    date: '',
    clientId: '',
    statut: 'En cours' as Vente['statut'],
    description: ''
  });

  const resetForm = () => {
    setFormData({
      produitService: '',
      montant: '',
      date: '',
      clientId: '',
      statut: 'En cours',
      description: ''
    });
    setVenteEnEdition(null);
  };

  const ouvrirDialogAjout = () => {
    resetForm();
    setDialogOuvert(true);
  };

  const ouvrirDialogEdition = (vente: Vente) => {
    setVenteEnEdition(vente);
    setFormData({
      produitService: vente.produitService,
      montant: vente.montant.toString(),
      date: vente.date,
      clientId: vente.clientId,
      statut: vente.statut,
      description: vente.description || ''
    });
    setDialogOuvert(true);
  };

  const sauvegarderVente = () => {
    if (!formData.produitService || !formData.montant || !formData.date || !formData.clientId) return;

    const venteData = {
      produitService: formData.produitService,
      montant: parseFloat(formData.montant),
      date: formData.date,
      clientId: formData.clientId,
      statut: formData.statut,
      description: formData.description
    };

    if (venteEnEdition) {
      onModifierVente(venteEnEdition.id, venteData);
    } else {
      onAjouterVente(venteData);
    }

    setDialogOuvert(false);
    resetForm();
  };

  const confirmerSuppression = (vente: Vente) => {
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer la vente "${vente.produitService}" ?`)) {
      onSupprimerVente(vente.id);
    }
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'dd/MM/yyyy', { locale: fr });
  };

  const formatEuro = (montant: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    }).format(montant);
  };

  // Calculs des totaux
  const totaux = useMemo(() => {
    const totalGeneral = ventes.reduce((sum, vente) => sum + vente.montant, 0);
    const totalConfirmees = ventes
      .filter(vente => vente.statut === 'Confirmée')
      .reduce((sum, vente) => sum + vente.montant, 0);
    const totalEnCours = ventes
      .filter(vente => vente.statut === 'En cours')
      .reduce((sum, vente) => sum + vente.montant, 0);

    return { totalGeneral, totalConfirmees, totalEnCours };
  }, [ventes]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <ShoppingBag className="h-5 w-5" />
          Suivi des Ventes ({ventes.length})
        </CardTitle>
        <Dialog open={dialogOuvert} onOpenChange={setDialogOuvert}>
          <DialogTrigger asChild>
            <Button onClick={ouvrirDialogAjout} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Nouvelle Vente
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {venteEnEdition ? 'Modifier la Vente' : 'Nouvelle Vente'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="produitService">Produit / Service</Label>
                <Input
                  id="produitService"
                  value={formData.produitService}
                  onChange={(e) => setFormData({ ...formData, produitService: e.target.value })}
                  placeholder="Ex: Développement site web"
                />
              </div>
              <div>
                <Label htmlFor="montant">Montant (€)</Label>
                <Input
                  id="montant"
                  type="number"
                  value={formData.montant}
                  onChange={(e) => setFormData({ ...formData, montant: e.target.value })}
                  placeholder="Ex: 5000"
                />
              </div>
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="clientId">Client</Label>
                <Select value={formData.clientId} onValueChange={(value) => setFormData({ ...formData, clientId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner un client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id}>
                        {client.nom}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="statut">Statut</Label>
                <Select value={formData.statut} onValueChange={(value: Vente['statut']) => setFormData({ ...formData, statut: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="En cours">En cours</SelectItem>
                    <SelectItem value="Confirmée">Confirmée</SelectItem>
                    <SelectItem value="Annulée">Annulée</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="description">Description (optionnel)</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Détails supplémentaires..."
                  rows={3}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setDialogOuvert(false)}>
                  Annuler
                </Button>
                <Button onClick={sauvegarderVente}>
                  {venteEnEdition ? 'Modifier' : 'Ajouter'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {/* Totaux */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Calculator className="h-4 w-4 text-blue-600" />
                <div>
                  <p className="text-sm text-muted-foreground">Total Général</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {formatEuro(totaux.totalGeneral)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Calculator className="h-4 w-4 text-green-600" />
                <div>
                  <p className="text-sm text-muted-foreground">Confirmées</p>
                  <p className="text-2xl font-bold text-green-600">
                    {formatEuro(totaux.totalConfirmees)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Calculator className="h-4 w-4 text-orange-600" />
                <div>
                  <p className="text-sm text-muted-foreground">En Cours</p>
                  <p className="text-2xl font-bold text-orange-600">
                    {formatEuro(totaux.totalEnCours)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tableau des ventes */}
        {ventes.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Aucune vente trouvée
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-4">Produit/Service</th>
                  <th className="text-left py-2 px-4">Montant</th>
                  <th className="text-left py-2 px-4">Date</th>
                  <th className="text-left py-2 px-4">Client</th>
                  <th className="text-left py-2 px-4">Statut</th>
                  <th className="text-left py-2 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {ventes.map((vente) => (
                  <tr key={vente.id} className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div>
                        <div className="font-medium">{vente.produitService}</div>
                        {vente.description && (
                          <div className="text-sm text-muted-foreground mt-1">
                            {vente.description}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-medium">
                      {formatEuro(vente.montant)}
                    </td>
                    <td className="py-3 px-4 text-sm">
                      {formatDate(vente.date)}
                    </td>
                    <td className="py-3 px-4 text-sm">
                      {obtenirNomClient(vente.clientId)}
                    </td>
                    <td className="py-3 px-4">
                      <Badge className={STATUTS_COULEURS[vente.statut]}>
                        {vente.statut}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => ouvrirDialogEdition(vente)}
                        >
                          <Edit2 className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => confirmerSuppression(vente)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
