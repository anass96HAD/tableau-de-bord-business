import { useMemo } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useBusinessData } from '@/hooks/useBusinessData';
import { ChiffresClesAvances } from './ChiffresClesAvances';
import { SuiviClients } from './SuiviClients';
import { SuiviVentes } from './SuiviVentes';
import { SuiviDepenses } from './SuiviDepenses';
import { GestionTaches } from './GestionTachesSimple';
import { FiltresTableauBord } from './FiltresTableauBord';
import { AlertesTableauBord } from './AlertesTableauBord';
import { BarChart3, Users, ShoppingBag, CheckSquare, Bell, Euro } from 'lucide-react';

export function TableauBordBusiness() {
  const {
    data,
    dataComplete,
    filtres,
    setFiltres,
    reinitialiserFiltres,
    chiffresCles,
    obtenirNomClient,
    // CRUD clients
    ajouterClient,
    modifierClient,
    supprimerClient,
    // CRUD ventes
    ajouterVente,
    modifierVente,
    supprimerVente,
    // CRUD tâches
    ajouterTache,
    modifierTache,
    supprimerTache,
    // CRUD dépenses
    ajouterDepense,
    modifierDepense,
    supprimerDepense,
    // CRUD alertes
    ajouterAlerte,
    modifierAlerte,
    supprimerAlerte,
    marquerAlerteCommeTraitee,
    snoozerAlerte,
    // Nouvelles fonctionnalités
    statistiquesAvancees,
    alertesActives,
    detecterAlertesAutomatiques
  } = useBusinessData();

  // Calcul des mois disponibles pour les filtres
  const moisDisponibles = useMemo(() => {
    const moisSet = new Set<string>();
    
    // Ajouter les mois des ventes
    dataComplete.ventes.forEach(vente => {
      moisSet.add(format(new Date(vente.date), 'yyyy-MM'));
    });
    
    // Ajouter les mois des tâches (échéances)
    dataComplete.taches.forEach(tache => {
      moisSet.add(format(new Date(tache.deadline), 'yyyy-MM'));
    });
    
    return Array.from(moisSet).sort().reverse();
  }, [dataComplete]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* En-tête */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <BarChart3 className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">
                Tableau de Bord Business
              </h1>
            </div>
            <div className="text-sm text-gray-500">
              Dernière mise à jour: {format(new Date(), 'dd/MM/yyyy HH:mm', { locale: fr })}
            </div>
          </div>
        </div>
      </header>

      {/* Contenu principal */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          {/* Section des filtres */}
          <FiltresTableauBord
            filtres={filtres}
            onChangerFiltres={setFiltres}
            onReinitialiserFiltres={reinitialiserFiltres}
            clients={dataComplete.clients}
            moisDisponibles={moisDisponibles}
          />

          {/* Onglets principales */}
          <Tabs defaultValue="alertes" className="space-y-6">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="alertes" className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                <span className="hidden sm:inline">Alertes</span>
                {alertesActives.length > 0 && (
                  <Badge variant="destructive" className="ml-1 h-5 w-5 p-0 text-xs">
                    {alertesActives.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="chiffres-cles" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">Chiffres Clés</span>
              </TabsTrigger>
              <TabsTrigger value="clients" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden sm:inline">Clients</span>
              </TabsTrigger>
              <TabsTrigger value="ventes" className="flex items-center gap-2">
                <ShoppingBag className="h-4 w-4" />
                <span className="hidden sm:inline">Ventes</span>
              </TabsTrigger>
              <TabsTrigger value="depenses" className="flex items-center gap-2">
                <Euro className="h-4 w-4" />
                <span className="hidden sm:inline">Dépenses</span>
              </TabsTrigger>
              <TabsTrigger value="taches" className="flex items-center gap-2">
                <CheckSquare className="h-4 w-4" />
                <span className="hidden sm:inline">Tâches</span>
              </TabsTrigger>
            </TabsList>

            {/* Contenu des onglets */}
            <TabsContent value="alertes" className="space-y-6">
              <AlertesTableauBord
                alertes={dataComplete.alertes}
                alertesDetectees={detecterAlertesAutomatiques}
                onMarquerCommeTraitee={marquerAlerteCommeTraitee}
                onSnoozer={snoozerAlerte}
                onSupprimerAlerte={supprimerAlerte}
                onAjouterAlerte={ajouterAlerte}
              />
            </TabsContent>

            <TabsContent value="chiffres-cles" className="space-y-6">
              <ChiffresClesAvances 
                statistiques={statistiquesAvancees}
                chiffresCles={chiffresCles}
              />
            </TabsContent>

            <TabsContent value="clients" className="space-y-6">
              <SuiviClients
                clients={data.clients}
                onAjouterClient={ajouterClient}
                onModifierClient={modifierClient}
                onSupprimerClient={supprimerClient}
              />
            </TabsContent>

            <TabsContent value="ventes" className="space-y-6">
              <SuiviVentes
                ventes={data.ventes}
                clients={dataComplete.clients}
                onAjouterVente={ajouterVente}
                onModifierVente={modifierVente}
                onSupprimerVente={supprimerVente}
                obtenirNomClient={obtenirNomClient}
              />
            </TabsContent>

            <TabsContent value="depenses" className="space-y-6">
              <SuiviDepenses
                depenses={data.depenses}
                onAjouterDepense={ajouterDepense}
                onModifierDepense={modifierDepense}
                onSupprimerDepense={supprimerDepense}
              />
            </TabsContent>

            <TabsContent value="taches" className="space-y-6">
              <GestionTaches
                taches={data.taches}
                clients={dataComplete.clients}
                onAjouterTache={ajouterTache}
                onModifierTache={modifierTache}
                onSupprimerTache={supprimerTache}
                obtenirNomClient={obtenirNomClient}
              />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Pied de page */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-500 text-sm">
            <p>Tableau de Bord Business - Gestion intégrée de votre activité</p>
            <p className="mt-2">
              {dataComplete.clients.length} clients • {dataComplete.ventes.length} ventes • {dataComplete.taches.length} tâches
              {alertesActives.length > 0 && (
                <span className="text-orange-600 font-medium"> • {alertesActives.length} alerte{alertesActives.length > 1 ? 's' : ''} active{alertesActives.length > 1 ? 's' : ''}</span>
              )}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
